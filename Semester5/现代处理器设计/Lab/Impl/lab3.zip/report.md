### 实验三：PC 寄存器模块与数据存储器模块设计实验报告

23级图灵实验班 2023202300 张昕跃 

-----

本实验中我实现了两个同步时序模块，PC 寄存器 `ProgramCounter.v` 与数据存储器 `DataMemory.v`。
同时编写了验证其行为的激励文件 `ProgramCounter_tb.v`、`DataMemory_tb.v`。
以下说明设计思路与预期结果。

---

### 文件设计

- **ProgramCounter.v**
  - 采用时钟沿变化触发的寄存器，收到reset将 `pcValue` 复位为 `0x00003000`。
  - 正常工作时默认自增 4。
  - 当 `jumpEnabled` 为 1 时，我采用同步更新，即在下一个时钟更新为 `jumpInput`响应跳转或分支（这里也可以设置为异步）。

- **ProgramCounter_tb.v**
  - 通过设计 `expect_pc` task 在每个关键时钟沿后断言 PC 的期望值。
  - 验证四种情况，复位置值、自增序列、跳转覆盖以及跳转后的继续自增。
  - 任何不匹配都会触发 `$fatal`，确保仿真失败立刻终止，成功输出OK。

- **DataMemory.v**
  - 用 32 位（4B） × 1024 深度的非打包数组 `buffer` 作为存储体（4KB），地址转换使用 `address[11:2]` （这里我们不用`address[31:2]`的隐式截断，因为1024就对应10位，我们直接算出来就好了防止可能有bug）。
  - reset信号时遍历数组初始化写零。
  - `readResult` 在每个时刻都会被调用读输出，保证地址变化时立即获得对应数据。
  - 写操作仅在clock信号变化且 `writeEnabled` 为 1 时生效。

- **DataMemory_tb.v**
  - 提供 `write_word` task生成对齐写入，`expect_read` 断言读值。
  - 验证上电复位读 0、写入多个地址再回读、访问未写地址读 0、再次复位清空等场景。
  - 所有检查通过后打印成功提示并 `$finish` 结束仿真。

---

### 预期实验结果

- 在 Vivado/其他仿真器中运行 `ProgramCounter_tb` 时，波形中 `pcValue` 应先在复位后跳至 `0x00003000`，随后依次为 `0x3004`、`0x3008`，当 `jumpEnabled` 设置后更新为 `0x4000`，再恢复顺序递增。

未接受到clock信号之前，`pcValue`为未知值，接收到clock为1的时候更新初始化为`0x3000`。
![alt text](img/image-5.png) 

接下来pc递增4。
![alt text](img/image-6.png)

再递增4。
![alt text](img/image-7.png)

设置了`jumpEnabled`为1和jumpInput之后跳转到对应地址。
![alt text](img/image-8.png)

最后在跳转到的地址上测试递增4成功，跑完测试案例。
![alt text](img/image-9.png)
![alt text](img/image-10.png)


- 运行 `DataMemory_tb` 时，`readResult` 初始为未知 `X`，复位完成后稳定为 0；写入 `0xDEADBEEF` 与 `0xCAFEBABE` 后对应地址读出相同数据，未写地址保持 0；再次设置 `reset` 后测试之前写入的地址读 0。

初始时刻，`writeEnabled`等变量都为0，`readResult`应该为未知表示地址没有可读数据。这个时候`reset`变量为1，要初始化。

![alt text](img/image.png)


下一时刻，`writeEnabled`变量为1，写入`writeInput`中初始化的0xdeadbeef，`readResult`同时读出。
![alt text](img/image2.png)

同时我们再在0x00000004写入0xcafebabe，并读出。

![alt text](img/image-1.png)

在0x00000008处，设置`writeEnabled`变量为0不写内容，直接读，发现`readResult`是0。

![alt text](img/image-2.png)

设置`reset`复位后读0x00000000应该还是0，成功。
![alt text](img/image-4.png)
![alt text](img/image-3.png)
