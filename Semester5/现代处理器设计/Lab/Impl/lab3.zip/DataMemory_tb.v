`timescale 1ns / 1ps

module DataMemory_tb;
    reg reset;
    reg clock;
    reg writeEnabled;
    reg [31:0] address;
    reg [31:0] writeInput;
    wire [31:0] readResult;

    DataMemory dut (
        .reset(reset),
        .clock(clock),
        .address(address),
        .writeEnabled(writeEnabled),
        .writeInput(writeInput),
        .readResult(readResult)
    );

    always #5 clock = ~clock;

    task automatic expect_read(input [31:0] expected);
        if (readResult !== expected) begin
            $error("Expected read = 0x%08h, got 0x%08h at time %0t", expected, readResult, $time);
            $fatal;
        end
    endtask

    task automatic write_word(input [31:0] addr, input [31:0] data);
        begin
            address = addr;
            writeInput = data;
            writeEnabled = 1'b1;
            @(posedge clock);
            #1;
            writeEnabled = 1'b0;
        end
    endtask

    initial begin
        clock = 1'b0;
        reset = 1'b1;
        writeEnabled = 1'b0;
        address = 32'h00000000;
        writeInput = 32'd0;

        @(posedge clock);
        #1;
        expect_read(32'h00000000);

        reset = 1'b0;

        write_word(32'h00000000, 32'hDEADBEEF);
        expect_read(32'hDEADBEEF);

        write_word(32'h00000004, 32'hCAFEBABE);
        #1;
        address = 32'h00000000;
        #1;
        expect_read(32'hDEADBEEF);

        address = 32'h00000004;
        #1;
        expect_read(32'hCAFEBABE);

        address = 32'h00000008;
        #1;
        expect_read(32'h00000000);

        reset = 1'b1;
        @(posedge clock);
        #1;
        expect_read(32'h00000000);
        reset = 1'b0;

        $display("DataMemory_tb completed successfully.");
        $finish;
    end
endmodule
