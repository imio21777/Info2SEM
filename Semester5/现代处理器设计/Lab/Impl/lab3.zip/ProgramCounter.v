`timescale 1ns / 1ps

// 同步复位，下一个时钟边沿才生效
module ProgramCounter (
    input        clock,
    input        reset,
    input        jumpEnabled,
    input  [31:0] jumpInput,
    output reg [31:0] pcValue
);

    always @(posedge clock) begin
        if (reset) begin
            pcValue <= 32'h0000_3000;

        end else if (jumpEnabled) begin
            pcValue <= jumpInput;
        end else begin
            pcValue <= pcValue + 32'd4;
        end
    end
endmodule

// // 异步复位，reset上升沿立刻生效
// module ProgramCounter (
//     input        clock,
//     input        reset,
//     input        jumpEnabled,
//     input  [31:0] jumpInput,
//     output reg [31:0] pcValue
// );

//     always @(postedge reset) begin
//         pcValue <= 32'h0000_3000;
//     end

//     always @(posedge clock) begin
//         if (jumpEnabled) begin
//             pcValue <= jumpInput;
//         end else begin
//             pcValue <= pcValue + 32'd4;
//         end
//     end
// endmodule
