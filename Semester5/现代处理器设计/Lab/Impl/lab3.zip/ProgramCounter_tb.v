`timescale 1ns / 1ps

module ProgramCounter_tb;
    reg reset;
    reg clock;
    reg jumpEnabled;
    reg [31:0] jumpInput;
    wire [31:0] pcValue;

    ProgramCounter dut (
        .reset(reset),
        .clock(clock),
        .jumpEnabled(jumpEnabled),
        .jumpInput(jumpInput),
        .pcValue(pcValue)
    );

    always #5 clock = ~clock;

    task automatic expect_pc(input [31:0] expected);
        if (pcValue !== expected) begin
            $error("Expected PC = 0x%08h, got 0x%08h at time %0t", expected, pcValue, $time);
            $fatal;
        end
    endtask

    initial begin
        clock = 1'b0;
        reset = 1'b1;
        jumpEnabled = 1'b0;
        jumpInput = 32'd0;

        @(posedge clock);
        #1;
        expect_pc(32'h00003000);

        reset = 1'b0;

        @(posedge clock);
        #1;
        expect_pc(32'h00003004);

        @(posedge clock);
        #1;
        expect_pc(32'h00003008);

        jumpInput = 32'h00004000;
        jumpEnabled = 1'b1;

        @(posedge clock);
        #1;
        expect_pc(32'h00004000);

        jumpEnabled = 1'b0;

        @(posedge clock);
        #1;
        expect_pc(32'h00004004);

        $display("ProgramCounter_tb completed successfully.");
        $finish;
    end
endmodule
