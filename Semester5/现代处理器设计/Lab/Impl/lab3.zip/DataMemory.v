`timescale 1ns / 1ps

module DataMemory (
    input         reset,
    input         clock,
    input  [31:0] address,
    input         writeEnabled,
    input  [31:0] writeInput,
    output [31:0] readResult
);

    wire [9:0] mem_addr;
    // 隐式截断，写成address[31:2]，其实也行
    // 但存储器深度为1024，log2(1024)=10，所以只需要address的10位（32位=4字节扣掉两位）
    assign mem_addr = address[11:2];

    // 4kb block
    reg [31:0] buffer [1023:0];
    assign readResult = buffer[mem_addr];

    integer i;
    always @(posedge clock) begin
        // initialize memory to zero on reset
        if (reset) begin
            for (i = 0; i < 1024; i = i + 1) begin
                buffer[i] <= 32'b0;
            end
        end
    end

    always @(posedge clock) begin
         if (writeEnabled) begin
            buffer[mem_addr] <= writeInput;
        end
    end
endmodule