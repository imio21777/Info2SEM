`ifndef REGFILE_SV
`define REGFILE_SV

`include "define.vh"

module RegFile(
    input  logic      reset,
    input  logic      clock,
    input  reg_id_t   readReg1,
    input  reg_id_t   readReg2,
    input  reg_id_t   writeReg,
    input  logic      writeEnabled,
    input  word_t     writeInput,
    output word_t     readResult1,
    output word_t     readResult2
);

    word_t data[31:0];

    assign readResult1 = data[readReg1];
    assign readResult2 = data[readReg2];

    // falling edge available
    integer i;
    always_ff @(negedge clock) begin
        // reset
        if (reset) begin
            for (i = 0; i < 32; i++) begin
                data[i] <= 32'h0;
            end
        end else if (writeEnabled && writeReg != 5'd0) begin
            data[writeReg] <= writeInput;
        end
    end
endmodule

`endif
