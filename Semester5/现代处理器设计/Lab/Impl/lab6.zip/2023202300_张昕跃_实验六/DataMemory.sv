`ifndef DATA_MEMORY_SV
`define DATA_MEMORY_SV

`include "define.vh"

module DataMemory(
    input logic reset,
    input logic clock,
    input word_t address,
    input logic writeEnabled,
    input word_t writeInput,
    output word_t readResult
    );

    word_t memory[0:2047];

    initial begin
      $readmemh(`DATA_PATH, memory,0,2047);
    end

    assign readResult = memory[address[12:2]];

    always_ff @(posedge clock) begin
        if (!reset && writeEnabled) begin
            memory[address[12:2]] <= writeInput;
        end
    end

endmodule
`endif