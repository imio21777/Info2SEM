`ifndef INSTRUCTION_MEMORY_SV
`define INSTRUCTION_MEMORY_SV
`include "define.vh"

module InstructionMemory(
    input word_t addr,
    output word_t inst
    );

    word_t memory [0:2047];

    initial begin
        $readmemh(`CODE_PATH, memory, 0, 2047);
    end

    assign inst = memory[addr[11:2]];
endmodule
`endif