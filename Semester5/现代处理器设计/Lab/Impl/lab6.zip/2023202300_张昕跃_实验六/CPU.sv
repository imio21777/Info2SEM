`ifndef CPU_SV
`define CPU_SV

`include "define.vh"
`include "ALU.sv"
`include "RegFile.sv"
`include "InstructionMemory.sv"
`include "DataMemory.sv"

module TopLevel(
    input logic reset,
    input logic clock
);

    // declare registers
    if_id_reg if_id;
    id_ex_reg id_ex;
    ex_mem_reg ex_mem;
    mem_wb_reg mem_wb;

    // instruction fetch
    word_t pcReg;
    word_t inst;
    InstructionMemory imem (
        .addr(pcReg),
        .inst(inst)
    );

    reg_id_t if_rs, if_rt, if_rd;
    assign if_rs = if_id.inst[25:21];
    assign if_rt = if_id.inst[20:16];
    assign if_rd = if_id.inst[15:11];

    word_t rf_rs_val, rf_rt_val; // the two data read from RegFile
    word_t wbData;              // data for write back
    logic  wbWriteEnabled;      // write enable signal
    reg_id_t wbWriteReg;       // register number to write back

    RegFile regfile (
        .reset(reset),
        .clock(clock),
        .readReg1(if_rs),
        .readReg2(if_rt),
        .writeEnabled(wbWriteEnabled),
        .writeReg(wbWriteReg),
        .writeInput(wbData),
        .readResult1(rf_rs_val),
        .readResult2(rf_rt_val)
    );

    // Hazard detection
    logic useRs, useRt;
    logic stall;

    // Decode control signals
    alu_op_t aluOp;
    logic useImm, isSyscall;
    logic regWrite, memToReg, memRead, memWrite;
    branch_t branch;
    word_t immExt, linkValue;
    reg_id_t dest;
    logic [25:0] jumpIndex;

    // Forward
    logic jumpEnabled;
    word_t jumpPC;
    logic flush; // kill wrong instructions in pipeline
    assign flush = jumpEnabled;

    // Update PC
    always_ff @(posedge clock) begin
        if (reset) begin
            pcReg <= `INIT_PC;
        end else if (!stall) begin
            // address PC
            if (jumpEnabled) begin
                pcReg <= jumpPC;
            end else begin
                pcReg <= pcReg + 4;
            end
        end else if (stall) begin
            pcReg <= pcReg; // hold PC
        end
    end

    // IF/ID register
    always_ff @(posedge clock) begin
        if (reset || flush) begin
            // reset all
            if_id <= '0;
        end else if (!stall) begin
            if_id.pcValue <= pcReg;
            if_id.inst    <= inst;
        end else if (stall) begin
            if_id <= if_id; // hold IF/ID reg
        end
    end

    // Decode
    word_t inst_bits;
    logic [5:0] opcode, funct;
    logic [15:0] imm16;
    logic imm_sign;
    logic [25:0] jumpAddr;

    assign inst_bits = if_id.inst;
    assign opcode    = inst_bits[31:26];
    assign funct     = inst_bits[5:0];
    assign imm16     = inst_bits[15:0];
    assign imm_sign  = imm16[15];
    assign jumpAddr  = inst_bits[25:0];

    logic [31:0] if_id_pc;
    assign if_id_pc = if_id.pcValue;

    // combinational logic for control signals
    always_comb begin
        // default values
        aluOp      = ALU_ADD;
        useImm     = 1'b0;
        regWrite   = 1'b0;
        memRead    = 1'b0;
        memWrite   = 1'b0;
        memToReg   = 1'b0;
        branch     = BR_NONE;
        dest       = 5'd0; // default write $0
        immExt     = {{16{imm_sign}}, imm16}; // sign-extend
        linkValue  = if_id_pc + 32'd8; // for jal
        jumpIndex  = jumpAddr;
        isSyscall  = 1'b0;
        useRs     = 1'b0;
        useRt     = 1'b0;

        // Address opcode
        case(opcode)
            6'b000000: begin // R-type
                case(funct)
                    6'b100001: begin // addu
                        aluOp    = ALU_ADD;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100011: begin // subu
                        aluOp    = ALU_SUB;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b001000: begin // jr
                        branch   = BR_JR;
                        useRs    = 1'b1;
                    end
                    6'b001100: begin // syscall
                        isSyscall = 1'b1;
                    end
                    default: begin
                        // NOP / unimplemented
                    end 
                endcase
            end
            6'b001101: begin // ori
                aluOp    = ALU_OR;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
                immExt   = {{16{1'b0}}, imm16}; // zero-extend
            end
            6'b100011: begin //lw
                aluOp    = ALU_ADD;
                regWrite = 1'b1;
                memToReg = 1'b1;
                memRead  = 1'b1;
                useImm   = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
            end
            6'b101011: begin //sw
                aluOp    = ALU_ADD;
                memWrite = 1'b1;
                useImm   = 1'b1;
                useRs    = 1'b1;
                useRt    = 1'b1;
            end
            6'b000100: begin // beq
                branch   = BR_BEQ;
                useRs    = 1'b1;
                useRt    = 1'b1;
            end
            6'b001111: begin // lui
                aluOp    = ALU_LUI;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                // immExt changed in ALU
            end
            6'b000011: begin // jal
                branch   = BR_JAL;
                aluOp    = ALU_PASS;
                regWrite = 1'b1;
                dest     = 5'd31; // $ra
            end
            6'b000010: begin // j
                branch   = BR_J;
            end
            default: begin
                // NOP / unimplemented
            end
        endcase
    end

    // Stall logic checking load-use hazard
    assign stall = 
        id_ex.memToReg && // load inst in EX stage
       // id_ex.regWrite &&
    (
        // use rs and cuurent inst needs rs
        (useRs && (id_ex.dest != 5'd0) && (id_ex.dest == if_rs)) ||
        (useRt && (id_ex.dest != 5'd0) && (id_ex.dest == if_rt))
    );

    // ID/EX register
    always_ff @(posedge clock) begin
        if (reset || stall) begin
            id_ex <= '0; // bubble to stall
        end else begin
            id_ex.pcValue   <= if_id.pcValue;
            id_ex.inst      <= if_id.inst;
            id_ex.rsVal     <= rf_rs_val;
            id_ex.rtVal     <= rf_rt_val;
            id_ex.immExt    <= immExt;
            id_ex.linkValue <= linkValue;
            id_ex.rs        <= if_rs;
            id_ex.rt        <= if_rt;
            id_ex.rd        <= if_rd;
            id_ex.dest      <= dest;
            // control signals
            id_ex.regWrite  <= regWrite;
            id_ex.memToReg  <= memToReg;
            id_ex.memRead   <= memRead;
            id_ex.memWrite  <= memWrite;
            id_ex.useImm    <= useImm;
            id_ex.aluOp     <= aluOp;
            id_ex.branch    <= branch;
            id_ex.jumpIndex <= jumpIndex;
            id_ex.isSyscall <= isSyscall;
        end
    end

    // Forward helper
    word_t memStageData, wbStageData;
    word_t aluInput2, aluCalcResult, aluRealResult;
    ALU alu (
        .op(id_ex.aluOp),
        .input1(forwardRsVal),
        .input2(aluInput2),
        .result(aluCalcResult)
    );

    // r-type or load inst
    assign wbStageData = mem_wb.memToReg ? mem_wb.memOut : mem_wb.aluExResult;

    // address forwarding logics and choose correct rs&rt vals
    logic forward_rs_ex_mem, forward_rs_mem_wb, forward_rt_ex_mem, forward_rt_mem_wb;

    assign forward_rs_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 && // not write into $0
     ex_mem.dest == id_ex.rs); // rs not written yet

    assign forward_rs_mem_wb = 
    (mem_wb.regWrite &&
     mem_wb.dest != 5'd0 &&
     mem_wb.dest == id_ex.rs);

    assign forward_rt_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 &&
     ex_mem.dest == id_ex.rt);

    assign forward_rt_mem_wb = 
    (mem_wb.regWrite &&
     mem_wb.dest != 5'd0 &&
     mem_wb.dest == id_ex.rt);

    word_t forwardRsVal, forwardRtVal;

    assign forwardRsVal =
    forward_rs_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rs_mem_wb ? wbStageData : id_ex.rsVal);

    assign forwardRtVal =
    forward_rt_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rt_mem_wb ? wbStageData : id_ex.rtVal);

    // branch logics
    logic [31:0] pcBase;
    logic [25:0] branchIndex;
    assign pcBase = id_ex.pcValue;
    assign branchIndex = id_ex.jumpIndex;

    logic [3:0] pcUpper;
    assign pcUpper = pcBase[31:28];

    // j & jal
    logic [31:0] jTarget;
    assign jTarget = {pcUpper, branchIndex, 2'b00};

    // beq
    logic [31:0] shiftOffset;
    assign shiftOffset = id_ex.immExt << 2;
    logic [31:0] beqTarget;
    assign beqTarget = pcBase + 32'd4 + shiftOffset;

    // Extract id_ex res
    branch_t id_ex_branch;
    reg_id_t id_ex_rs, id_ex_rt;
    word_t   id_ex_rs_val, id_ex_rt_val;
    logic    id_ex_use_imm;
    word_t   id_ex_imm_ext;
    word_t   id_ex_link_value;

    assign id_ex_branch     = id_ex.branch;
    assign id_ex_rs         = id_ex.rs;
    assign id_ex_rt         = id_ex.rt;
    assign id_ex_rs_val     = id_ex.rsVal;
    assign id_ex_rt_val     = id_ex.rtVal;
    assign id_ex_use_imm    = id_ex.useImm;
    assign id_ex_imm_ext    = id_ex.immExt;
    assign id_ex_link_value = id_ex.linkValue;

    logic branchTaken;
    word_t branchTarget;

    always_comb begin

       // correct vals 
       aluInput2 = id_ex_use_imm ? id_ex_imm_ext : forwardRtVal;

       aluRealResult = (id_ex_branch == BR_JAL) ? id_ex_link_value : aluCalcResult;

       branchTaken = 1'b0;
       branchTarget = 32'd0;

       case(id_ex_branch)
            BR_BEQ: begin
                branchTaken = (forwardRsVal == forwardRtVal);
                branchTarget = beqTarget;
            end
            BR_J: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JAL: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JR: begin
                branchTaken = 1'b1;
                branchTarget = forwardRsVal;
            end
            default: begin
                // already initialized, do nothing
            end
         endcase
    end

    assign jumpEnabled = branchTaken;
    assign jumpPC = branchTarget;

    // EX/MEM register
    always_ff @(posedge clock) begin
        if (reset) begin
            ex_mem <= '0;
        end else begin
            ex_mem.pcValue      <= id_ex.pcValue;
            ex_mem.inst         <= id_ex.inst;
            ex_mem.aluExResult  <= aluRealResult;
            ex_mem.swVal        <= forwardRtVal;
            ex_mem.dest         <= id_ex.dest;
            // control signals
            ex_mem.regWrite     <= id_ex.regWrite;
            ex_mem.memToReg     <= id_ex.memToReg;
            ex_mem.memRead      <= id_ex.memRead;
            ex_mem.memWrite     <= id_ex.memWrite;
            ex_mem.isSyscall    <= id_ex.isSyscall;
        end
    end

    // MEM stage
    word_t memRawData;
    DataMemory dataMemory (
        .clock(clock),
        .reset(reset),
        .address(ex_mem.aluExResult),
        .writeEnabled(ex_mem.memWrite),
        .writeInput(ex_mem.swVal),
        .readResult(memRawData)
    );

    // choose through r-type or load inst
    assign memStageData = ex_mem.memToReg ? memRawData : ex_mem.aluExResult;
        
    // MEM/WB register
    always_ff @(posedge clock) begin
        if (reset) begin
            mem_wb <= '0;
        end else begin
            mem_wb.pcValue      <= ex_mem.pcValue;
            mem_wb.inst         <= ex_mem.inst;
            mem_wb.aluExResult <= ex_mem.aluExResult;
            mem_wb.memOut      <= memRawData;
            mem_wb.dest         <= ex_mem.dest;
            // control signals
            mem_wb.regWrite     <= ex_mem.regWrite;
            mem_wb.memToReg     <= ex_mem.memToReg;
            mem_wb.isSyscall    <= ex_mem.isSyscall;
        end
    end

    // write back
    assign wbWriteEnabled  = mem_wb.regWrite && !reset;
    assign wbWriteReg = mem_wb.dest;
    assign wbData = wbStageData;

    // print output
        always @(posedge clock) begin
        if (!reset && wbWriteEnabled) begin
            $display("@%h: $%2d <= %h", mem_wb.pcValue, mem_wb.dest, wbData);
        end
        if (ex_mem.memWrite && !reset) begin
            $display("@%h: *%h <= %h", ex_mem.pcValue, ex_mem.aluExResult, ex_mem.swVal);
        end
        if (!reset && mem_wb.isSyscall) begin
            $finish;
        end
    end
endmodule

`endif