`ifndef ALU_SV
`define ALU_SV

`include "define.vh"

module ALU(
    input  alu_op_t op,
    input  word_t   input1,
    input  word_t   input2,
    output word_t   result
);
    logic [15:0] b_lower;
    assign b_lower = input2[15:0];

    always_comb begin
        case (op)
            ALU_ADD:   result = input1 + input2;
            ALU_SUB:   result = input1 - input2;
            ALU_OR:    result = input1 | input2;
            ALU_LUI:   result = {b_lower, 16'h0000};
            ALU_PASS:  result = input2;
            default:   result = input2;
        endcase
    end
endmodule

`endif
