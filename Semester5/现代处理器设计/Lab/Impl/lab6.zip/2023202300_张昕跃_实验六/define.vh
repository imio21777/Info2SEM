`ifndef DEFINE_VH
`define DEFINE_VH

`define CODE_PATH "code.txt"
`define DATA_PATH "data.txt"
`define INIT_PC   32'h0000_3000

// 32 位数据信号
typedef logic [31:0] word_t;
// 定义寄存器索引为 5位 (2^5 = 32个寄存器)
typedef logic [4:0]  reg_id_t;

typedef enum logic [2:0] {
    ALU_ADD,
    ALU_SUB,
    ALU_OR,
    ALU_LUI,
    ALU_PASS
} alu_op_t;

typedef enum logic [2:0] {
    BR_NONE,
    BR_BEQ,
    BR_J,
    BR_JAL,
    BR_JR
} branch_t;

typedef struct packed {
    word_t pcValue;
    word_t inst;
} if_id_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t rsVal;
    word_t rtVal;
    word_t immExt;
    word_t linkValue; // for jal

    reg_id_t rs;
    reg_id_t rt;
    reg_id_t rd;
    reg_id_t dest;

    // control signals
    logic    regWrite;  // RegWrite Enable Signal
    logic    memToReg;  // write back src, MemtoReg: 0=ALU, 1=DataMem
    logic    memRead;   // MemRead
    logic    memWrite;  // MemWrite
    logic    useImm;    // ALUSrc: 0=rtVal, 1=immExt
    
    alu_op_t aluOp;
    branch_t branch;

    logic [25:0] jumpIndex;

    logic isSyscall;
} id_ex_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t aluExResult;
    word_t swVal;      // from rtVal, for sw into dm

    reg_id_t dest; // which reg to write back

    // control signals
    logic    regWrite;
    logic    memToReg;
    logic    memRead;
    logic    memWrite;
    logic    isSyscall;
    
} ex_mem_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t aluExResult;
    word_t memOut;

    reg_id_t dest;
    
    //control signals
    logic regWrite;
    logic memToReg;
    logic isSyscall;
    
} mem_wb_reg;

`endif
