### 实验五：流水线 CPU 设计 - 10条指令

**23级图灵实验班 2023202300 张昕跃**

-----
根据实验要求，在此仅说明流水线竞争处理。

#### 1. CPU结构

首先我的CPU重要逻辑结构全写在了 `CPU.sv` 中了，其他的 `ALU`、`IM`、`DM`、`RF` 组件对应的 `.sv` 文件内容都很简单。

`CPU.sv` 中实现了五级流水的段间寄存器旁路转发和冒险检测，也就是直接按照流水顺序来了。

#### 2. 具体竞争

##### 2.1 结构冒险

由于 `DM` 和 `IM` 分开设计，所以不存在结构冒险。

##### 2.2 数据冒险

结合课上所说，其实就是解决 **RAW** 的问题。主要有以下三类：

1. **ALU后的数据冒险**：前一条指令在 EX 或 MEM 阶段计算结果，后一条指令在 ID 阶段读取。

用 **EX/MEM** 或者 **MEM/WB** 进行旁路转发，将段间寄存器堆中的结果直接传递给 `ALU` 的输入端，无需等待写回。

具体来说我设计了四个控制信号 `forward_rs_ex_mem`, `forward_rs_mem_wb`, `forward_rt_ex_mem`, `forward_rt_mem_wb`，来决定 rs，rt 是哪个的值要被转发，同时是哪一个段间寄存器要进行转发。

信号上，判断前序指令（处于 MEM 或 WB 阶段）的目标寄存器与当前指令（处于 EX 阶段）的源寄存器（rs/rt）是否相同。

然后实现 **MUX** 逻辑，根据判断结果，选择正确的数据源。优先选 **EX/MEM**，其次取 **MEM/WB**，最后取原值。

这之中对于 **EX/MEM**，如果算术类指令用 `ALU` 的执行结果，否则还需要用 memory 中的 data，对于 **MEM/WB** 也同理。

类似于 ppt 中所写实现逻辑即可：
![alt text](img/image.png)

这里限于篇幅，只给我对于 **rs**，在 **EX/MEM** 的实现：
```verilog
    logic forward_rs_ex_mem;

    assign forward_rs_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 && // not write into $0
     ex_mem.dest == id_ex.rs); // rs not written yet

    word_t forwardRsVal;
    // need to get data from each RF stage
    word_t memStageData, wbStageData;
    assign memStageData = ex_mem.memToReg ? memRawData : ex_mem.aluExResult;
    assign wbStageData = mem_wb.memToReg ? mem_wb.memOut : mem_wb.aluExResult;

    assign forwardRsVal =
    forward_rs_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rs_mem_wb ? wbStageData : id_ex.rsVal);
```

2. **lw后的数据冒险**：前一条是 `lw`，数据需在 MEM 阶段读出，而后一条指令在 EX 阶段就需要使用。
这时候必须 **stall**，`lw` 指令的结果无法通过旁路送 `ALU`，因此必须插入 **bubble**。

因此定义控制信号 `stall`，先判断是不是读内存的 `lw` 指令，然后检查当前 IF 取到的指令用的寄存器和 `lw` 操作的寄存器是否相同。

> lw数据冒险这里就不放ppt的图了

```verilog
  assign stall = 
        id_ex.memToReg && // lw inst in EX stage
    (
        // use rs and cuurent inst needs rs
        (useRs && (id_ex.dest != 5'd0) && (id_ex.dest == if_rs)) ||
        (useRt && (id_ex.dest != 5'd0) && (id_ex.dest == if_rt))
    );
```

然后如果遇到 `stall` 为真，就不要改各个段间寄存器的内容，如果为假，推进更新就好。

以 **IF/ID** 寄存器为例长这样，其他段间寄存器同理就好：：
```verilog
    // IF/ID register
    always_ff @(posedge clock) begin
        if (reset || flush) begin
            // reset all
            if_id <= '0;
        end else if (!stall) begin
            if_id.pcValue <= pcReg;
            if_id.inst    <= inst;
        end else if (stall) begin
            if_id <= if_id; // hold IF/ID reg
        end
    end
```

##### 2.3 控制冒险

`beq` 等分支指令会导致：分支跳转指令在 EX 阶段才计算出是否跳转以及目标地址，此时下一条指令已经被取入 IF 阶段。

我采用 **预测不跳转 + flush** (**没有采用延迟槽**)

默认顺序取指，若在 EX 阶段发现需要跳转，则废弃当前 IF 阶段取到的指令（清空 **IF/ID**），并更新 `PC` 为跳转 `addr`。

具体以下这个组合逻辑更新对应指令所要用到的跳转情况，在 EX 阶段完成分支判断：
```verilog
    always_comb begin

       branchTaken = 1'b0;
       branchTarget = 32'd0;

       case(id_ex_branch)
            BR_BEQ: begin
                branchTaken = (forwardRsVal == forwardRtVal);
                branchTarget = beqTarget;
            end
            BR_J: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JAL: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JR: begin
                branchTaken = 1'b1;
                branchTarget = forwardRsVal;
            end
            default: begin
                // already initialized, do nothing
            end
         endcase
    end
```

还需要定义控制信号来决定跳转，并与 `flush` 联系上，在段间寄存器中仅用 `flush` 就好（且这里只有上面看到的 **IF/ID** 段间寄存器需要 `flush` 信号进行 reset）：
```verilog 
    logic flush, jumpEnabled;
    assign flush = jumpEnabled;
    assign jumpEnabled = branchTaken;
    assign jumpPC = branchTarget;
```

对于目标地址的计算，这里只以 `beq` 为例，然后在组合逻辑中赋值就可以：
```verilog
    logic [31:0] shiftOffset;
    assign shiftOffset = id_ex.immExt << 2;
    logic [31:0] beqTarget;
    assign beqTarget = id_ex.pcValue + 32'd4 + shiftOffset;
```

#### 3. 实验结果

用 `iVerilog` 编译，`k=50000` 的情况下，跑了100次实验都是和 **Mars** 一样的输出，保证了正确性。
![alt text](img/image-1.png)