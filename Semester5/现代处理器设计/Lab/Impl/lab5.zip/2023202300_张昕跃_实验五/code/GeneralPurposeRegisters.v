module GeneralPurposeRegisters (
    input         clock,
    input         reset,
    input         reg_write_en,      // 写使能信号
    input  [4:0]  read_reg1,         // rs 地址
    input  [4:0]  read_reg2,         // rt 地址
    input  [4:0]  write_reg,         // rd 或 rt 地址
    input  [31:0] write_data,        // 要写入的数据
    output [31:0] read_data1,        // rs 的数据
    output [31:0] read_data2         // rt 的数据
);
    
    reg [31:0] registers [0:31];
    integer i;

    // 异步读
    assign read_data1 = (read_reg1 == 5'b0) ? 32'b0 : registers[read_reg1];
    assign read_data2 = (read_reg2 == 5'b0) ? 32'b0 : registers[read_reg2];
    
    // 同步写
    always @(posedge clock or posedge reset) begin
        if (reset) begin
            for (i = 0; i < 32; i = i + 1) begin
                registers[i] <= 32'b0;
            end
        end else if (reg_write_en && (write_reg != 5'b0)) begin
            registers[write_reg] <= write_data;
        end
    end

endmodule