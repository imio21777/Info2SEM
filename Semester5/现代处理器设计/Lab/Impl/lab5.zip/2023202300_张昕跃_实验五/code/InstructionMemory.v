module InstructionMemory (
    input      [31:0] address,
    output reg [31:0] instruction
);

    // 4KiB = 1024 words (1 word = 32 bits = 4 bytes)
    // 地址是字节地址，但存储器是按字组织的，所以需要右移2位
    // PC 从 0x3000 开始，截断后指向 memory[0]
    reg [31:0] memory [0:1023];

    // 初始化
    initial begin
        // 路径必须是绝对路径
        $readmemh("/home/user/projects/cpu_impl/code.txt",memory);
    end

    // 异步读取
    // PC地址 0x...3000 -> mem[0], 0x...3004 -> mem[1] ...
    // address[11:2] 是字地址索引
    always @(*) begin
        instruction = memory[address[11:2]];
    end

endmodule

