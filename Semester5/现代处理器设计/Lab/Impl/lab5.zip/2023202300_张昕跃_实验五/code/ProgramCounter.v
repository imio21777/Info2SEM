module ProgramCounter (
    input        clock,
    input        reset,
    input  [31:0] pc_in,      // 下一个PC的值，由顶层逻辑计算
    output reg [31:0] pc_out  // 当前PC的值
);

    initial begin
        pc_out = 32'h00003000;
    end
    
    always @(posedge clock or posedge reset) begin
        if (reset) begin
            pc_out <= 32'h00003000;
        end else begin
            pc_out <= pc_in;
        end
    end

endmodule