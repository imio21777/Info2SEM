module ALU (
    input  [31:0] a,
    input  [31:0] b,
    input  [3:0]  alu_op,     // 控制信号，自定义操作码
    output reg [31:0] result,
    output reg        zero      // 结果是否为0，用于beq
);
    // 自行定义 alu_op 的编码
    parameter OP_ADD  = 4'b0000;
    parameter OP_SUB  = 4'b0001;
    parameter OP_OR   = 4'b0010;
    parameter OP_LUI  = 4'b0011; // b << 16

    always @(*) begin
        case (alu_op)
            OP_ADD: result = a + b;
            OP_SUB: result = a - b;
            OP_OR:  result = a | b;
            OP_LUI: result = b << 16;
            default: result = 32'hxxxxxxxx;
        endcase
        
        if (result == 32'b0) begin
            zero = 1'b1;
        end else begin
            zero = 1'b0;
        end
    end

endmodule