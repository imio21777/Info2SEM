module ControllerUnit (
    input  [5:0] opcode,
    input  [5:0] funct,
    output reg   reg_write_en,
    output reg   mem_to_reg,     // MUX: 1=mem_data, 0=alu_result
    output reg   mem_read_en,
    output reg   mem_write_en,
    output reg   alu_src,        // MUX: 1=immediate, 0=reg_data2
    output reg   reg_dst,        // MUX: 1=rd, 0=rt
    output reg   branch,         // BEQ 指令
    output reg   jump,           // JAL/JR 指令
    output reg   jal_en,         // JAL 指令，用于存PC+4到$ra
    output reg [3:0] alu_op
);
    // 定义指令的 opcode 和 funct 常量
    // R-Type
    parameter OP_RTYPE = 6'b000000;
    parameter FUNCT_ADDU = 6'b100001;
    parameter FUNCT_SUBU = 6'b100011;
    parameter FUNCT_JR   = 6'b001000;
    parameter FUNCT_SYSCALL = 6'b001100;
    // I-Type
    parameter OP_ORI  = 6'b001101;
    parameter OP_LW   = 6'b100011;
    parameter OP_SW   = 6'b101011;
    parameter OP_BEQ  = 6'b000100;
    parameter OP_LUI  = 6'b001111;
    // J-Type
    parameter OP_JAL  = 6'b000011;

    // 定义ALU操作码
    parameter ALU_ADD  = 4'b0000;
    parameter ALU_SUB  = 4'b0001;
    parameter ALU_OR   = 4'b0010;
    parameter ALU_LUI  = 4'b0011;

    always @(*) begin
        // 先设置默认值，避免产生 latch
        reg_write_en = 1'b0; mem_to_reg = 1'b0; mem_read_en = 1'b0;
        mem_write_en = 1'b0; alu_src = 1'b0; reg_dst = 1'b0;
        branch = 1'b0; jump = 1'b0; jal_en = 1'b0; alu_op = 4'bxxxx;

        case (opcode)
            OP_RTYPE: begin // addu, subu, jr, syscall
                case (funct)
                    FUNCT_ADDU: begin
                        reg_write_en = 1'b1; reg_dst = 1'b1; alu_op = ALU_ADD;
                    end
                    FUNCT_SUBU: begin
                        reg_write_en = 1'b1; reg_dst = 1'b1; alu_op = ALU_SUB;
                    end
                    FUNCT_JR: begin
                        jump = 1'b1;
                    end
                    FUNCT_SYSCALL: begin
                        // 特殊处理，在顶层模块中实现 $finish
                    end
                endcase
            end
            OP_LW: begin
                reg_write_en = 1'b1; mem_to_reg = 1'b1; mem_read_en = 1'b1;
                alu_src = 1'b1; alu_op = ALU_ADD;
            end
            OP_SW: begin
                mem_write_en = 1'b1; alu_src = 1'b1; alu_op = ALU_ADD;
            end
            OP_BEQ: begin
                branch = 1'b1; alu_op = ALU_SUB; // 用减法判断是否相等
            end
            OP_ORI: begin
                reg_write_en = 1'b1; alu_src = 1'b1; alu_op = ALU_OR;
            end
            OP_LUI: begin
                reg_write_en = 1'b1; alu_src = 1'b1; alu_op = ALU_LUI;
            end
            OP_JAL: begin
                reg_write_en = 1'b1; jump = 1'b1; jal_en = 1'b1;
            end
            default: begin
                // 无效指令处理
            end
        endcase
    end
endmodule