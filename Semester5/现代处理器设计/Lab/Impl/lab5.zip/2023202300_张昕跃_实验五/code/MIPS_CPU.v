module MIPS_CPU (
    input reset,
    input clock
);

    // Wires for connecting modules
    wire [31:0] pc_current, pc_next, pc_plus_4;
    wire [31:0] instruction;
    wire [31:0] reg_read_data1, reg_read_data2;
    wire [31:0] alu_result, alu_b;
    wire [31:0] extended_imm, write_back_data, mem_read_data;
    wire [4:0]  write_reg_addr;
    wire        alu_zero;
    
    // Control signals
    wire reg_write_en, mem_to_reg, mem_read_en, mem_write_en;
    wire alu_src, reg_dst, branch, jump, jal_en;
    wire [3:0] alu_op;
    
    // 1. PC
    ProgramCounter pc_unit (
        .clock(clock), .reset(reset),
        .pc_in(pc_next), .pc_out(pc_current)
    );
    
    // 2. Instruction Memory
    InstructionMemory im_unit (
        .address(pc_current), .instruction(instruction)
    );
    
    // 3. Controller
    ControllerUnit ctrl_unit (
        .opcode(instruction[31:26]), .funct(instruction[5:0]),
        .reg_write_en(reg_write_en), .mem_to_reg(mem_to_reg),
        .mem_read_en(mem_read_en), .mem_write_en(mem_write_en),
        .alu_src(alu_src), .reg_dst(reg_dst),
        .branch(branch), .jump(jump), .jal_en(jal_en),
        .alu_op(alu_op)
    );

    // 4. Register File
    assign write_reg_addr = reg_dst ? instruction[15:11] : instruction[20:16];
    GeneralPurposeRegisters reg_file_unit (
        .clock(clock), .reset(reset), .reg_write_en(reg_write_en),
        .read_reg1(instruction[25:21]), .read_reg2(instruction[20:16]),
        .write_reg(jal_en ? 5'd31 : write_reg_addr), // JAL writes to $ra ($31)
        .write_data(write_back_data),
        .read_data1(reg_read_data1), .read_data2(reg_read_data2)
    );
    
    // 5. Immediate Extender (for I-Type)
    // ori: zero-extend, others: sign-extend
    assign extended_imm = (instruction[31:26] == 6'b001101) ? {16'b0, instruction[15:0]} : {{16{instruction[15]}}, instruction[15:0]};
    
    // 6. ALU
    assign alu_b = alu_src ? extended_imm : reg_read_data2;
    ALU alu_unit (
        .a(reg_read_data1), .b(alu_b),
        .alu_op(alu_op), .result(alu_result), .zero(alu_zero)
    );
    
    // 7. Data Memory
    DataMemory dm_unit (
        .clock(clock), .mem_write_en(mem_write_en), .mem_read_en(mem_read_en),
        .address(alu_result), .write_data(reg_read_data2),
        .read_data(mem_read_data)
    );

    // 8. Write-back MUX
    assign pc_plus_4 = pc_current + 4;
    assign write_back_data = jal_en ? pc_plus_4 : (mem_to_reg ? mem_read_data : alu_result);
    
    // 9. PC_next logic
    wire branch_taken = branch & alu_zero;
    wire [31:0] branch_target = pc_plus_4 + (extended_imm << 2);
    wire [31:0] jump_target_jal = {pc_plus_4[31:28], instruction[25:0], 2'b00};
    wire [31:0] jump_target_jr = reg_read_data1;
    
    assign pc_next = branch_taken ? branch_target : 
                     (jump ? (jal_en ? jump_target_jal : jump_target_jr) : pc_plus_4);
                     
    // 10. Syscall handler
    always @(*) begin
        if (instruction[31:26] == 6'b0 && instruction[5:0] == 6'b001100) begin
            $display("Syscall detected. Simulation finished at time %t.", $time);
            $finish;
        end
    end

endmodule