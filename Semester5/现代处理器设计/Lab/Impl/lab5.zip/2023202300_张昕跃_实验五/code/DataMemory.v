module DataMemory (
    input        clock,
    input        mem_write_en,  // 写使能
    input        mem_read_en,   // 读使能 (在单周期中通常可以省略)
    input [31:0] address,
    input [31:0] write_data,
    output reg [31:0] read_data
);

    // 4KiB = 1024 words
    reg [31:0] memory [0:1023];
    integer i;

    initial begin
        for(i = 0; i < 1024; i = i + 1) begin
            memory[i] = 32'b0;
        end
    end

    // 异步读
    always @(*) begin
        if (mem_read_en) begin
            read_data = memory[address[11:2]];
        end else begin
            read_data = 32'hxxxxxxxx;
        end
    end

    // 同步写
    always @(posedge clock) begin
        if (mem_write_en) begin
            memory[address[11:2]] <= write_data;
        end
    end

endmodule