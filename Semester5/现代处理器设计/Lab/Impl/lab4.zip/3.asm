# 任务3：跳跃游戏

.data
true_str:  .asciiz "True"
false_str: .asciiz "False"

.text
.globl main

main:
    # 读取数组大小 n
    li   $v0, 5           # read integer n
    syscall
    move $s0, $v0         # $s0 = n

    # 为数组动态分配内存，需要 n * 4 字节
    sll  $a0, $s0, 2      # $a0 = n * 4
    li   $v0, 9           # syscall 9：sbrk
    syscall
    move $s1, $v0         # $s1 = 数组的基地址

    # 循环读取 n 个整数到数组中
    li   $t0, 0           # $t0 = 循环计数器 i = 0
    move $t1, $s1         # $t1 = 当前元素的地址
    j    read_loop

read_loop:
    bge  $t0, $s0, start_check # if (i >= n) goto start_check
    
    li   $v0, 5           # read integer
    syscall
    sw   $v0, 0($t1)      # save integer to memory address $t1
    
    addi $t1, $t1, 4      # 地址指向下一个整数
    addi $t0, $t0, 1      # i++
    j    read_loop

start_check:
    # 贪心算法实现
    li   $t0, 0           # $t0 = i (当前位置)
    li   $t1, 0           # $t1 = farthest (能到达的最远位置)
    
check_loop:
    # 循环条件: i < n
    bge  $t0, $s0, end_check_loop
    
    # 检查当前位置 i 是否可达
    # (i > farthest) then it's impossible to proceed
    bgt  $t0, $t1, print_false

    # 计算从当前位置能跳到的最远距离: i + A[i]
    sll  $t2, $t0, 2      # $t2 = i * 4 (字节偏移量)
    add  $t2, $s1, $t2    # $t2 = &A[i] (A[i]的地址），加上基址
    lw   $t3, 0($t2)      # $t3 = A[i] (A[i]的值)
    add  $t4, $t0, $t3    # $t4 = i + A[i] (从i能跳到的最远位置)
    
    # 更新全局最远 farthest = max(farthest, i + A[i])
    bgt  $t4, $t1, update_farthest
    j    continue_loop

update_farthest:
    move $t1, $t4         # farthest = i + A[i]

continue_loop:
    # 判断是否已经能到达终点
    addi $t5, $s0, -1     # $t5 = n - 1 (终点下标)
    bge  $t1, $t5, print_true # (farthest >= n - 1) then success

    addi $t0, $t0, 1      # i++
    j    check_loop

end_check_loop:
    # 循环正常结束，最后再判断一次 farthest 是否到达终点
    addi $t5, $s0, -1     # $t5 = n-1
    bge  $t1, $t5, print_true
    j    print_false
    
print_true:
    la   $a0, true_str
    li   $v0, 4
    syscall
    j    exit

print_false:
    la   $a0, false_str
    li   $v0, 4
    syscall
    j    exit

exit:
    li   $v0, 10
    syscall