# 任务2：计算斐波那契数列 F(n), F(0)=1, F(1)=1

.data
# 无需数据

.text
.globl main

main:
    # read n
    li   $v0, 5           # syscall 5：read integer to $v0
    syscall              
    move $s0, $v0         # save n to $s0

    # 处理特殊情况 n=0 或 n=1
    li   $t0, 1           # 准备结果为 1
    # branch less than or equal to 1
    ble  $s0, 1, print_result # if (n <= 1), F(n) = 1, 直接跳转到输出

    # 迭代计算 F(n) for n > 1, initialization
    li   $t1, 1           # F(i-1), 初始为 F(0) = 1
    li   $t2, 1           # F(i),   初始为 F(1) = 1
    li   $t3, 2           # 循环计数器 i, 从 2 开始

fib_loop:
    # 循环条件: i <= n, $s0 = n
    bgt  $t3, $s0, print_result # if (i > n) goto print_result
    
    # calc F(i) = F(i-1) + F(i-2)
    add  $t4, $t1, $t2    # t4 = F(i-1) + F(i)
    
    # 更新下一次迭代的值
    move $t1, $t2         # 新的 F(i-1) 是当前的 F(i)
    move $t2, $t4         # 新的 F(i) 是刚计算出的 F(i+1)
    
    # 更新计数器
    addi $t3, $t3, 1      # i++
    
    j    fib_loop         # 继续循环

print_result:
    move $a0, $t2         # F(n) 在 $t2 中
    li   $v0, 1           # syscall 1：print integer in $a0
    syscall

    # exit
    li   $v0, 10          # syscall 10：exit
    syscall