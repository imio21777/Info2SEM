# 先读取长、宽、高三个值，然后统一检查。
# 如果有任何一个值非法（<=0），则输出错误信息并重新读取三个值。

.data
illegal_msg: .asciiz "Illegal Input\n"
newline:     .asciiz "\n"

.text
.globl main

main:
    # 循环读取和验证输入
read_loop:
    # 读取长暂存到 $t0
    li   $v0, 5             # 系统调用号 5：read integer
    syscall
    move $t0, $v0

    # 读取宽暂存到 $t1
    li   $v0, 5             # 系统调用号 5：read integer
    syscall
    move $t1, $v0

    # 读取高暂存到 $t2
    li   $v0, 5             # 系统调用号 5：read integer
    syscall
    move $t2, $v0

    # ----------------------------------------------------
    # 统一检查三个输入值是否都大于 0 (Branch on Less Than or Equal to Zero)
    # ----------------------------------------------------
    blez $t0, illegal_input  # if (length <= 0) goto illegal_input
    blez $t1, illegal_input  # if (width <= 0) goto illegal_input
    blez $t2, illegal_input  # if (height <= 0) goto illegal_input

    # all checks passed
    # 将合法的值从临时寄存器移动到保存寄存器
    move $s0, $t0            # $s0 = length
    move $s1, $t1            # $s1 = width
    move $s2, $t2            # $s2 = height
    j    calculate           # 跳转 calculate

illegal_input:
    # illegal input handling
    la   $a0, illegal_msg    # load illegal_msg address to $a0
    li   $v0, 4              # 系统调用号 4：print string
    syscall
    j    read_loop           # 跳转回 read_loop 重新读取三个数

# 计算体积和表面积
calculate:
    # volume = length * width * height
    mul  $t0, $s0, $s1   # t0 = length * width
    mul  $t0, $t0, $s2   # t0 = t0 * height (最终体积)
    
    # area = 2 * (lw + lh + wh)
    mul  $t1, $s0, $s1   # t1 = length * width
    mul  $t2, $s0, $s2   # t2 = length * height
    mul  $t3, $s1, $s2   # t3 = width * height
    add  $t4, $t1, $t2   # t4 = lw + lh
    add  $t4, $t4, $t3   # t4 = lw + lh + wh
    sll  $t4, $t4, 1     # t4 = t4 * 2 (最终表面积)

    # 输出体积
    move $a0, $t0       
    li   $v0, 1          # 系统调用号 1：print integer $a0
    syscall
    
    # 输出换行符
    la   $a0, newline
    li   $v0, 4         # 系统调用号 4：print string $a0
    syscall

    # 输出表面积
    move $a0, $t4
    li   $v0, 1          # 系统调用号 1：print integer $a0
    syscall

    j    end_program

end_program:
    li   $v0, 10         # 系统调用号 10：exit
    syscall