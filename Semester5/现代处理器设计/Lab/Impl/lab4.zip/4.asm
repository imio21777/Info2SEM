
# C Code:
# int a, b, *D;
# for (int i = 0; i < a; i++)
#     for (int j = 0; j < b; j++)
#         D[4*j] = i + j;
#
# 寄存器:
# a: $s0
# b: $s1
# D: $s2 (数组基址)
# i: $t0
# j: $t1

.data
; array: .space 1000 # 为调试分配一些空间

.text
.globl main
main:
;     # 为调试设置 a, b, D 的初始值
;     li   $s0, 5           # a = 5
;     li   $s1, 10          # b = 10
;     la   $s2, array       # D = &array
    # 初始化外层循环变量 i = 0
    li   $t0, 0           # i = 0

outer_loop:
    # 外层循环: if (i >= a) goto end_outer_loop
    bge  $t0, $s0, end_outer_loop

    # 初始化内层循环变量 j = 0
    li   $t1, 0           # j = 0
    j    inner_loop
    
inner_loop:
    # 内层循环条件检查: if (j >= b) goto end_inner_loop
    bge  $t1, $s1, end_inner_loop

    # --- 循环体开始: D[4*j] = i + j; ---

    # 1. 计算 D[4*j] 的地址
    # 字节偏移量 = 4 * j * 4 = 16 * j
    sll  $t2, $t1, 4      # $t2 = j * 16
    add  $t3, $s2, $t2    # $t3 = &D + $t2 = &D[4*j]

    # 2. 计算要存入的值 i + j
    add  $t4, $t0, $t1    # $t4 = i + j

    # 3. 执行存储操作
    sw   $t4, 0($t3)      # M[t3] = t4, 即 D[4*j] = i + j

    # 内层循环变量更新: j++
    addi $t1, $t1, 1
    j    inner_loop

end_inner_loop:
    # 外层循环变量更新: i++
    addi $t0, $t0, 1
    j    outer_loop

end_outer_loop:
    # 循环结束，exit
    li   $v0, 10
    syscall