### 实验七：50 条指令流水线 CPU 设计

**23级图灵实验班 2023202300 张昕跃**

-----

对于竞争设计，参考以下10条指令的实验报告。

注意！我提交的代码中不包含`mips_tb.v`和`MultiplicationDivisionUnit.sv`

-----
根据实验要求，在此仅说明流水线竞争处理。

#### 1. CPU结构

首先我的CPU重要逻辑结构全写在了 `CPU.sv` 中了，其他的 `ALU`、`IM`、`DM`、`RF` 组件对应的 `.sv` 文件内容都很简单。

`CPU.sv` 中实现了五级流水的段间寄存器旁路转发和冒险检测，也就是直接按照流水顺序来了。

#### 2. 具体竞争

##### 2.1 结构冒险

由于 `DM` 和 `IM` 分开设计，所以不存在结构冒险。

##### 2.2 数据冒险

结合课上所说，其实就是解决 **RAW** 的问题。主要有以下三类：

1. **ALU后的数据冒险**：前一条指令在 EX 或 MEM 阶段计算结果，后一条指令在 ID 阶段读取。

用 **EX/MEM** 或者 **MEM/WB** 进行旁路转发，将段间寄存器堆中的结果直接传递给 `ALU` 的输入端，无需等待写回。

具体来说我设计了四个控制信号 `forward_rs_ex_mem`, `forward_rs_mem_wb`, `forward_rt_ex_mem`, `forward_rt_mem_wb`，来决定 rs，rt 是哪个的值要被转发，同时是哪一个段间寄存器要进行转发。

信号上，判断前序指令（处于 MEM 或 WB 阶段）的目标寄存器与当前指令（处于 EX 阶段）的源寄存器（rs/rt）是否相同。

然后实现 **MUX** 逻辑，根据判断结果，选择正确的数据源。优先选 **EX/MEM**，其次取 **MEM/WB**，最后取原值。

这之中对于 **EX/MEM**，如果算术类指令用 `ALU` 的执行结果，否则还需要用 memory 中的 data，对于 **MEM/WB** 也同理。

类似于 ppt 中所写实现逻辑即可：
![alt text](img/image.png)

这里限于篇幅，只给我对于 **rs**，在 **EX/MEM** 的实现：
```verilog
    logic forward_rs_ex_mem;

    assign forward_rs_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 && // not write into $0
     ex_mem.dest == id_ex.rs); // rs not written yet

    word_t forwardRsVal;
    // need to get data from each RF stage
    word_t memStageData, wbStageData;
    assign memStageData = ex_mem.memToReg ? memRawData : ex_mem.aluExResult;
    assign wbStageData = mem_wb.memToReg ? mem_wb.memOut : mem_wb.aluExResult;

    assign forwardRsVal =
    forward_rs_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rs_mem_wb ? wbStageData : id_ex.rsVal);
```

2. **lw后的数据冒险**：前一条是 `lw`，数据需在 MEM 阶段读出，而后一条指令在 EX 阶段就需要使用。
这时候必须 **stall**，`lw` 指令的结果无法通过旁路送 `ALU`，因此必须插入 **bubble**。

因此定义控制信号 `stall`，先判断是不是读内存的 `lw` 指令，然后检查当前 IF 取到的指令用的寄存器和 `lw` 操作的寄存器是否相同。

> lw数据冒险这里就不放ppt的图了

```verilog
  assign stall = 
        id_ex.memToReg && // lw inst in EX stage
    (
        // use rs and cuurent inst needs rs
        (useRs && (id_ex.dest != 5'd0) && (id_ex.dest == if_rs)) ||
        (useRt && (id_ex.dest != 5'd0) && (id_ex.dest == if_rt))
    );
```

然后如果遇到 `stall` 为真，就不要改各个段间寄存器的内容，如果为假，推进更新就好。

以 **IF/ID** 寄存器为例长这样，其他段间寄存器同理就好：：
```verilog
    // IF/ID register
    always_ff @(posedge clock) begin
        if (reset || flush) begin
            // reset all
            if_id <= '0;
        end else if (!stall) begin
            if_id.pcValue <= pcReg;
            if_id.inst    <= inst;
        end else if (stall) begin
            if_id <= if_id; // hold IF/ID reg
        end
    end
```

##### 2.3 控制冒险

`beq` 等分支指令会导致：分支跳转指令在 EX 阶段才计算出是否跳转以及目标地址，此时下一条指令已经被取入 IF 阶段。

我采用 **预测不跳转 + flush** (**没有采用延迟槽**)

默认顺序取指，若在 EX 阶段发现需要跳转，则废弃当前 IF 阶段取到的指令（清空 **IF/ID**），并更新 `PC` 为跳转 `addr`。

具体以下这个组合逻辑更新对应指令所要用到的跳转情况，在 EX 阶段完成分支判断：
```verilog
    always_comb begin

       branchTaken = 1'b0;
       branchTarget = 32'd0;

       case(id_ex_branch)
            BR_BEQ: begin
                branchTaken = (forwardRsVal == forwardRtVal);
                branchTarget = beqTarget;
            end
            BR_J: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JAL: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JR: begin
                branchTaken = 1'b1;
                branchTarget = forwardRsVal;
            end
            default: begin
                // already initialized, do nothing
            end
         endcase
    end
```

还需要定义控制信号来决定跳转，并与 `flush` 联系上，在段间寄存器中仅用 `flush` 就好（且这里只有上面看到的 **IF/ID** 段间寄存器需要 `flush` 信号进行 reset）：
```verilog 
    logic flush, jumpEnabled;
    assign flush = jumpEnabled;
    assign jumpEnabled = branchTaken;
    assign jumpPC = branchTarget;
```

对于目标地址的计算，这里只以 `beq` 为例，然后在组合逻辑中赋值就可以：
```verilog
    logic [31:0] shiftOffset;
    assign shiftOffset = id_ex.immExt << 2;
    logic [31:0] beqTarget;
    assign beqTarget = id_ex.pcValue + 32'd4 + shiftOffset;
```

#### 3. 实验结果

用 `iVerilog` 编译，`k=50000` 的情况下，跑了100次实验都是和 **Mars** 一样的输出，保证了正确性。
![alt text](img/image-1.png)

------

### 50条指令实验报告

在此，由于添加指令逻辑可以几近参考10条指令，不再赘述，但由于老师要求添加一下关于控制信号的设计，后面有一个部分是关于控制信号设计。

与10条指令不同的是这里添加的MDU和非对齐读写设计，除此之外还有实现一下1和10号的syscall。

超出实验要求的是，过程中我发现我的cpu有些行数比mars超出很多，发现是因为我没有实现溢出检测。即出现溢出不是调用syscall退出，而是继续运行，也添加了对于溢出的检测。

#### 4. 非对齐读写（在MEM级实现，但要从ID开始传递）


定义`memReadType`/`memWriteType`控制信号，并在ID阶段进行标记，通过 `id_ex`、`ex_mem` 一直传递传递，直到 MEM 级确定访问宽度与扩展方式。

DM 始终按 `address[12:2]`读取 32 位对齐字，MEM 级中的 `memRawData` 是该对齐字。用组合逻辑，便于在同一周期完成字节/半字拼装。

接着拼接读到的数据，根据指令不同，判断 `ex_mem.aluExResult[1:0]` 选取字节，再结合 `memReadType` 做符号或零扩展。

合并后得到 `memReadData`，通过 MEM/WB，被 `memStageData` 选用，供写回或后续转发。

非对齐写的时候，只要改写目标段。即读 `memReadType` ，也是根据 `aluExResult[1:0]` 替换对应目标字节，合并后的 `memWriteData` 在上升沿写入 DM 即可。

这里以SB命令和LB命令为例：
```verilog
// in DM
assign readResult = memory[address[12:2]];
always_ff @(posedge clock) begin
    if (!reset && writeEnabled) begin
        memory[address[12:2]] <= writeInput;
    end
end
```

``` verilog
// MEM stage
assign memWriteAddr = {ex_mem.aluExResult[31:2], 2'b00};
assign memWriteEnabled = (ex_mem.memWriteType != MEM_WRITE_NONE);


// SB：先读出对齐字 `memRawData`，只替换目标字节，其余字节保持不变，
always @(*) begin
    memWriteData = ex_mem.swVal;
    case (ex_mem.memWriteType)
        MEM_WRITE_BYTE: begin
            case (ex_mem.aluExResult[1:0])
                2'b00: memWriteData = {memRawData[31:8], ex_mem.swVal[7:0]};
                2'b01: memWriteData = {memRawData[31:16], ex_mem.swVal[7:0], memRawData[7:0]};
                2'b10: memWriteData = {memRawData[31:24], ex_mem.swVal[7:0], memRawData[15:0]};
                2'b11: memWriteData = {ex_mem.swVal[7:0], memRawData[23:0]};
            endcase
        end
        // ...
    endcase
end
// 后续写回DM     

// LB：按地址低 2 位选字节后做符号扩展，得到最终读出数据。
always @(*) begin
    memReadData = memRawData;
    case (ex_mem.memReadType)
        MEM_READ_BYTE_SIGNED: begin 
            case (ex_mem.aluExResult[1:0])
                2'b00: memReadData = {{24{memRawData[7]}}, memRawData[7:0]};
                2'b01: memReadData = {{24{memRawData[15]}}, memRawData[15:8]};
                2'b10: memReadData = {{24{memRawData[23]}}, memRawData[23:16]};
                2'b11: memReadData = {{24{memRawData[31]}}, memRawData[31:24]};
            endcase
        end
        // ...
    endcase
end

// 后续再转发。
assign memStageData = ex_mem.memToReg ? memReadData : ex_mem.aluExResult;
```

#### 5. MDU 实现

控制信号上，设计 `mduUse`/`mduStart`/`mduOp`，根据指令给ID阶段的指令不同赋值即可，如下：
``` verilog
6'b011000: begin // mult
    useMdu   = 1'b1;
    mduStart = 1'b1;
    mduOp    = MDU_START_SIGNED_MUL;
    useRs    = 1'b1;
    useRt    = 1'b1;
end
6'b010000: begin // mfhi
    useMdu   = 1'b1;
    mduOp    = MDU_READ_HI;
    regWrite = 1'b1;
    dest     = if_rd;
end
```

首先确定是否需要stall，当 ID 阶段发出 MDU 指令且 MDU 忙或 EX 级正启动新运算时，ID/IF stall，避免新的 MDU 指令进入 EX 与正在运行的运算冲突。

只有在 MDU 空闲时才可以使用，防止重复启动：`mduStartExec = id_ex.mduStart && !mduBusy`，

操作数使用转发后的 `forwardRsVal/forwardRtVal` 作为 MDU 的 `operand1/operand2`，避免 RAW 冒险影响乘除法操作数。

最终结果选择写回有两种情况：
- 对 `MFHI/MFLO`，EX 级将 `mduDataRead` 送入 `aluRealResult`，复用原有写回通路，WB 阶段按普通 ALU 结果写入寄存器。
- 对 `MULT/MULTU/DIV/DIVU/MTHI/MTLO`，MDU 内部更新 `HI/LO`，不更新寄存器堆。

```verilog
// EX stage
// need stall?
assign stallMdu = useMdu && (mduBusy || id_ex.mduStart);
// not busy then start
assign mduStartExec = id_ex.mduStart && !mduBusy;

assign mduOp1 = forwardRsVal;
assign mduOp2 = forwardRtVal;

MultiplicationDivisionUnit mdu (
    .reset(reset),
    .clock(clock),
    .operand1(mduOp1),
    .operand2(mduOp2),
    .operation(id_ex.mduOp),
    .start(mduStartExec),
    .busy(mduBusy),
    .dataRead(mduDataRead)
);

// write res back
if (id_ex.mduUse && (id_ex.mduOp == MDU_READ_HI || id_ex.mduOp == MDU_READ_LO)) begin
    aluRealResult = mduDataRead;
end
```

#### 6. 1号和10号syscall 实现

先识别 syscall 并读取参数，在IF/ID 阶段检测存在 `opcode=0` 且  `funct=0x0c`，强制 RegFile 读 `$v0`（功能号） 与 `$a0`（参数）。

EX 级将 `$v0` 送到 `aluExResult`，同时将 `$a0` 通过 `swVal`传到 MEM/WB，最终在 WB 级使用。

WB 时处理 syscall，当 `mem_wb.isSyscall=1` 时，分两种情况：
  - `v0 == 1`：输出 `a0`（按有符号整数打印）。
  - `v0 == 10`：结束仿真（`$finish`）。

```verilog
// IF/ID 读寄存器
assign isSyscallInst =
    (if_id.inst[31:26] == 6'b000000) &&
    (if_id.inst[5:0] == 6'b001100);
assign rfReadReg1 = isSyscallInst ? 5'd2 : if_rs; // $v0
assign rfReadReg2 = isSyscallInst ? 5'd4 : if_rt; // $a0

// EX 级选择 syscall 输出，把 $v0 当ALU 结果传递
if (id_ex.isSyscall) begin
    aluRealResult = forwardRsVal; // v0
end
// ...

// MEM/WB 传递 a0
ex_mem.swVal <= forwardRtVal; // a0
mem_wb.memOut <= ex_mem.isSyscall ? ex_mem.swVal : memReadData;

// WB 级执行
if (!reset && mem_wb.isSyscall && !mem_wb.exception) begin
    case (mem_wb.aluExResult)
        32'd1:  $display("%d", $signed(mem_wb.memOut));  // print_int
        32'd10: $finish;                                 // exit
        default: $finish;
    endcase
end
```

#### 7. 实现溢出检测
只对 signed 的 `ADD/ADDI/SUB` 打开溢出检测，`ADDU/ADDIU/SUBU` 不触发溢出异常。
通过符号位判断溢出：
  - 加法：`input1` 与 `input2` 同号且结果符号变号。
  - 减法：`input1` 与 `input2` 异号且结果符号变号。
  - 
ALU中判断溢出标记，这里以add为例：
```verilog
always @(*) begin
    overflow = 1'b0;
    case (op)
        ALU_ADD: begin
            result = input1 + input2;
            overflow = (~(input1[31] ^ input2[31]) & (input1[31] ^ result[31]));
        end
        // ...
    endcase
end

6'b100000: begin // add
    aluOp    = ALU_ADD;
    regWrite = 1'b1;
    dest     = if_rd;
    useRs    = 1'b1;
    useRt    = 1'b1;
    overflowCheck = 1'b1;
end
```

EX 级生成 `exception` 并写入 `ex_mem.exception`，同时清空本条指令的写回/访存控制信号，避免异常指令，WB 级检测到异常后输出提示并结束仿真。
```verilog
// EX -> MEM
assign exception = aluOverflow && id_ex.overflowCheck;
if (exception) begin
    ex_mem.regWrite     <= 1'b0;
    ex_mem.memToReg     <= 1'b0;
    ex_mem.memRead      <= 1'b0;
    ex_mem.memWrite     <= 1'b0;
    ex_mem.isSyscall    <= 1'b0;
    ex_mem.memReadType  <= MEM_READ_NONE;
    ex_mem.memWriteType <= MEM_WRITE_NONE;
end
// ...

// WB judge
if (!reset && mem_wb.exception) begin
    $display("Runtime exception at 0x%h: arithmetic overflow", mem_wb.pcValue);
    $finish;
end
```

#### 8. 控制信号设计
列出50条指令在 ID 生成的主要控制信号组合，未特别列出的信号均使用默认值。

##### 默认值 (ID 级译码初值)
- `aluOp = ALU_ADD`
- `useImm = 0`
- `useShamt = 0`
- `regWrite = 0`
- `memToReg = 0`
- `memRead = 0`
- `memWrite = 0`
- `memReadType = MEM_READ_NONE`
- `memWriteType = MEM_WRITE_NONE`
- `useMdu = 0`
- `mduStart = 0`
- `mduOp = MDU_READ_HI`
- `branch = BR_NONE`
- `dest = 5'd0`
- `immExt = sign-extend` (默认符号扩展)
- `isSyscall = 0`
- `useRs = 0`, `useRt = 0`

###### R-type (ALU/shift/jump)

| Inst | aluOp | useImm | useShamt | regWrite | dest | useRs | useRt | branch | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADD | ALU_ADD | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | signed add |
| ADDU | ALU_ADDU | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | unsigned add |
| SUB | ALU_SUB | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | signed sub |
| SUBU | ALU_SUBU | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | unsigned sub |
| AND | ALU_AND | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE |  |
| OR | ALU_OR | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE |  |
| XOR | ALU_XOR | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE |  |
| NOR | ALU_NOR | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE |  |
| SLT | ALU_SLT | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | signed compare |
| SLTU | ALU_SLTU | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | unsigned compare |
| SLL | ALU_SLL | 0 | 1 | 1 | rd | 0 | 1 | BR_NONE | shamt -> input1 |
| SRL | ALU_SRL | 0 | 1 | 1 | rd | 0 | 1 | BR_NONE | shamt -> input1 |
| SRA | ALU_SRA | 0 | 1 | 1 | rd | 0 | 1 | BR_NONE | shamt -> input1 |
| SLLV | ALU_SLL | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | rs -> shift amount |
| SRLV | ALU_SRL | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | rs -> shift amount |
| SRAV | ALU_SRA | 0 | 0 | 1 | rd | 1 | 1 | BR_NONE | rs -> shift amount |
| JR | (n/a) | 0 | 0 | 0 | - | 1 | 0 | BR_JR | jump to rs |
| JALR | (n/a) | 0 | 0 | 1 | rd | 1 | 0 | BR_JALR | write PC+8 |

##### I-type (immediate & ALU)

| Inst | aluOp | useImm | regWrite | dest | useRs | immExt | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ADDI | ALU_ADD | 1 | 1 | rt | 1 | sign |  |
| ADDIU | ALU_ADDU | 1 | 1 | rt | 1 | sign |  |
| ANDI | ALU_AND | 1 | 1 | rt | 1 | zero | immExt = zero-extend |
| ORI | ALU_OR | 1 | 1 | rt | 1 | zero | immExt = zero-extend |
| XORI | ALU_XOR | 1 | 1 | rt | 1 | zero | immExt = zero-extend |
| SLTI | ALU_SLT | 1 | 1 | rt | 1 | sign |  |
| SLTIU | ALU_SLTU | 1 | 1 | rt | 1 | sign |  |
| LUI | ALU_LUI | 1 | 1 | rt | 0 | sign | input2 used |

##### Branch / Jump (J-type, I-branch)

| Inst | branch | useRs | useRt | regWrite | Notes |
| --- | --- | --- | --- | --- | --- |
| BEQ | BR_BEQ | 1 | 1 | 0 | compare rs/rt |
| BNE | BR_BNE | 1 | 1 | 0 | compare rs/rt |
| BLEZ | BR_BLEZ | 1 | 0 | 0 | compare rs <= 0 |
| BGTZ | BR_BGTZ | 1 | 0 | 0 | compare rs > 0 |
| BGEZ | BR_BGEZ | 1 | 0 | 0 | opcode=000001, rt=00001 |
| BLTZ | BR_BLTZ | 1 | 0 | 0 | opcode=000001, rt=00000 |
| J | BR_J | 0 | 0 | 0 | jumpIndex -> target |
| JAL | BR_JAL | 0 | 0 | 1 | dest=31, write PC+8 |

##### Memory (load/store)

| Inst | aluOp | useImm | regWrite | memToReg | memRead | memWrite | memReadType | memWriteType | dest | useRs | useRt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| LB | ALU_ADD | 1 | 1 | 1 | 1 | 0 | MEM_READ_BYTE_SIGNED | - | rt | 1 | 0 |
| LBU | ALU_ADD | 1 | 1 | 1 | 1 | 0 | MEM_READ_BYTE_UNSIGNED | - | rt | 1 | 0 |
| LH | ALU_ADD | 1 | 1 | 1 | 1 | 0 | MEM_READ_HALF_SIGNED | - | rt | 1 | 0 |
| LHU | ALU_ADD | 1 | 1 | 1 | 1 | 0 | MEM_READ_HALF_UNSIGNED | - | rt | 1 | 0 |
| LW | ALU_ADD | 1 | 1 | 1 | 1 | 0 | MEM_READ_WORD | - | rt | 1 | 0 |
| SB | ALU_ADD | 1 | 0 | 0 | 0 | 1 | - | MEM_WRITE_BYTE | - | 1 | 1 |
| SH | ALU_ADD | 1 | 0 | 0 | 0 | 1 | - | MEM_WRITE_HALF | - | 1 | 1 |
| SW | ALU_ADD | 1 | 0 | 0 | 0 | 1 | - | MEM_WRITE_WORD | - | 1 | 1 |

##### MDU (HI/LO)

| Inst | useMdu | mduStart | mduOp | regWrite | dest | useRs | useRt | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MULT | 1 | 1 | MDU_START_SIGNED_MUL | 0 | - | 1 | 1 | start when not busy |
| MULTU | 1 | 1 | MDU_START_UNSIGNED_MUL | 0 | - | 1 | 1 | start when not busy |
| DIV | 1 | 1 | MDU_START_SIGNED_DIV | 0 | - | 1 | 1 | start when not busy |
| DIVU | 1 | 1 | MDU_START_UNSIGNED_DIV | 0 | - | 1 | 1 | start when not busy |
| MFHI | 1 | 0 | MDU_READ_HI | 1 | rd | 0 | 0 | read HI to GPR |
| MFLO | 1 | 0 | MDU_READ_LO | 1 | rd | 0 | 0 | read LO to GPR |
| MTHI | 1 | 0 | MDU_WRITE_HI | 0 | - | 1 | 0 | write HI = rs |
| MTLO | 1 | 0 | MDU_WRITE_LO | 0 | - | 1 | 0 | write LO = rs |

##### syscall

| Inst | isSyscall | useRs | useRt | regWrite | memRead | memWrite | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| SYSCALL | 1 | 1 | 1 | 0 | 0 | 0 | rfReadReg1/2 forced to $v0/$a0 |

- EX 级将 `$v0` 通过 `aluExResult` 传到 WB。  
- MEM/WB 级将 `$a0` 放到 `memOut`。  
- WB 级根据 `aluExResult` 判断 `1` 或 `10`。  
#### 9. 实验结果

对于500次随机测试点：
![alt text](img/image-3.png)

溢出测试点，都成功显示算术溢出：

![alt text](img/image-2.png)


对于给出的所有汇编测试点，都成功通过，结果如下：

![alt text](img/image-4.png)