`timescale 1us/1us
`ifndef DEFINE_VH
`define DEFINE_VH

`define CODE_PATH "code.txt"
`define DATA_PATH "data.txt"
`define INIT_PC   32'h0000_3000
`include "MultiplicationDivisionUnit.sv"

// 32 位数据信号
typedef logic [31:0] word_t;
// 定义寄存器索引为 5位 (2^5 = 32个寄存器)
typedef logic [4:0]  reg_id_t;

typedef enum logic [3:0] {
    ALU_ADD,
    ALU_ADDU,
    ALU_SUB,
    ALU_SUBU,
    ALU_AND,
    ALU_OR,
    ALU_XOR,
    ALU_NOR,
    ALU_SLT,
    ALU_SLTU,
    ALU_SLL,
    ALU_SRL,
    ALU_SRA,
    ALU_LUI,
    ALU_PASS
} alu_op_t;

typedef enum logic [3:0] {
    BR_NONE,
    BR_BEQ,
    BR_BNE,
    BR_BLEZ,
    BR_BGTZ,
    BR_BGEZ,
    BR_BLTZ,
    BR_J,
    BR_JAL,
    BR_JR,
    BR_JALR
} branch_t;

typedef enum logic [2:0] {
    MEM_READ_NONE,
    MEM_READ_WORD,
    MEM_READ_BYTE_SIGNED,
    MEM_READ_BYTE_UNSIGNED,
    MEM_READ_HALF_SIGNED,
    MEM_READ_HALF_UNSIGNED
} mem_read_t;

typedef enum logic [1:0] {
    MEM_WRITE_NONE,
    MEM_WRITE_BYTE,
    MEM_WRITE_HALF,
    MEM_WRITE_WORD
} mem_write_t;


typedef struct packed {
    word_t pcValue;
    word_t inst;
} if_id_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t rsVal;
    word_t rtVal;
    word_t immExt;
    word_t linkValue; // for jal

    reg_id_t rs;
    reg_id_t rt;
    reg_id_t rd;
    reg_id_t dest;

    // control signals
    logic    regWrite;  // RegWrite Enable Signal
    logic    memToReg;  // write back src, MemtoReg: 0=ALU, 1=DataMem
    logic    memRead;   // MemRead
    logic    memWrite;  // MemWrite
    logic    useImm;    // ALUSrc: 0=rtVal, 1=immExt
    logic    useShamt;  // ALUSrc1: 0=rsVal, 1=shamt
    
    alu_op_t aluOp;
    branch_t branch;

    logic [25:0] jumpIndex;

    mem_read_t memReadType;
    mem_write_t memWriteType;

    logic mduUse;
    logic mduStart;
    mdu_operation_t mduOp;

    logic isSyscall;
    logic overflowCheck;
} id_ex_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t aluExResult;
    word_t swVal;      // from rtVal, for sw into dm

    reg_id_t dest; // which reg to write back

    // control signals
    logic    regWrite;
    logic    memToReg;
    logic    memRead;
    logic    memWrite;
    logic    isSyscall;

    mem_read_t memReadType;
    mem_write_t memWriteType;
    logic exception;
} ex_mem_reg;

typedef struct packed {
    word_t pcValue;
    word_t inst;
    word_t aluExResult;
    word_t memOut;

    reg_id_t dest;
    
    //control signals
    logic regWrite;
    logic memToReg;
    logic isSyscall;
    logic exception;
    
} mem_wb_reg;

`endif
