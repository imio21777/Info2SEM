`timescale 1us/1us

`ifndef ALU_SV
`define ALU_SV

`include "define.vh"

module ALU(
    input  alu_op_t op,
    input  word_t   input1,
    input  word_t   input2,
    output word_t   result,
    output logic    overflow
);
    always @(*) begin
        overflow = 1'b0;
        case (op)
            ALU_ADD: begin
                result = input1 + input2;
                overflow = (~(input1[31] ^ input2[31]) & (input1[31] ^ result[31]));
            end
            ALU_ADDU: result = input1 + input2;
            ALU_SUB: begin
                result = input1 - input2;
                overflow = ((input1[31] ^ input2[31]) & (input1[31] ^ result[31]));
            end
            ALU_SUBU: result = input1 - input2;
            ALU_AND:  result = input1 & input2;
            ALU_OR:   result = input1 | input2;
            ALU_XOR:  result = input1 ^ input2;
            ALU_NOR:  result = ~(input1 | input2);
            ALU_SLT:  result = ($signed(input1) < $signed(input2)) ? 32'd1 : 32'd0;
            ALU_SLTU: result = (input1 < input2) ? 32'd1 : 32'd0;
            ALU_SLL:  result = input2 << input1[4:0];
            ALU_SRL:  result = input2 >> input1[4:0];
            ALU_SRA:  result = $signed(input2) >>> input1[4:0];
            ALU_LUI:  result = {input2[15:0], 16'h0000};
            ALU_PASS: result = input2;
            default:  result = input2;
        endcase
    end
endmodule

`endif
