`timescale 1us/1us

`ifndef CPU_SV
`define CPU_SV

`include "define.vh"
`include "ALU.sv"
`include "MultiplicationDivisionUnit.sv"
`include "RegFile.sv"
`include "InstructionMemory.sv"
`include "DataMemory.sv"

module TopLevel(
    input logic reset,
    input logic clock
);

    // declare registers
    if_id_reg if_id;
    id_ex_reg id_ex;
    ex_mem_reg ex_mem;
    mem_wb_reg mem_wb;

    // instruction fetch
    word_t pcReg;
    word_t inst;
    InstructionMemory imem (
        .addr(pcReg),
        .inst(inst)
    );

    reg_id_t if_rs, if_rt, if_rd;
    assign if_rs = if_id.inst[25:21];
    assign if_rt = if_id.inst[20:16];
    assign if_rd = if_id.inst[15:11];

    logic isSyscallInst;
    assign isSyscallInst =
        (if_id.inst[31:26] == 6'b000000) &&
        (if_id.inst[5:0] == 6'b001100);

    reg_id_t rfReadReg1, rfReadReg2;
    assign rfReadReg1 = isSyscallInst ? 5'd2 : if_rs;
    assign rfReadReg2 = isSyscallInst ? 5'd4 : if_rt;

    word_t rf_rs_val, rf_rt_val; // the two data read from RegFile
    word_t wbData;              // data for write back
    logic  wbWriteEnabled;      // write enable signal
    reg_id_t wbWriteReg;       // register number to write back

    RegFile regfile (
        .reset(reset),
        .clock(clock),
        .readReg1(rfReadReg1),
        .readReg2(rfReadReg2),
        .writeEnabled(wbWriteEnabled),
        .writeReg(wbWriteReg),
        .writeInput(wbData),
        .readResult1(rf_rs_val),
        .readResult2(rf_rt_val)
    );

    reg_id_t dec_rs, dec_rt, dec_rd;
    assign dec_rs = rfReadReg1;
    assign dec_rt = rfReadReg2;
    assign dec_rd = if_rd;

    // Hazard detection
    logic useRs, useRt;
    logic stall;
    logic mduBusy;

    // Decode control signals
    alu_op_t aluOp;
    logic useImm, useShamt, isSyscall;
    logic overflowCheck;
    logic regWrite, memToReg, memRead, memWrite;
    mem_read_t memReadType;
    mem_write_t memWriteType;
    logic useMdu, mduStart;
    mdu_operation_t mduOp;
    branch_t branch;
    word_t immExt, linkValue;
    reg_id_t dest;
    logic [25:0] jumpIndex;

    // Forward
    logic jumpEnabled;
    word_t jumpPC;
    logic flush; // kill wrong instructions in pipeline
    assign flush = jumpEnabled && !stall;

    // Update PC
    always_ff @(posedge clock) begin
        if (reset) begin
            pcReg <= `INIT_PC;
        end else if (jumpEnabled) begin
            pcReg <= jumpPC;
        end else if (!stall) begin
            pcReg <= pcReg + 4;
        end else if (stall) begin
            pcReg <= pcReg; // hold PC
        end
    end

    // IF/ID register
    always_ff @(posedge clock) begin
        if (reset || flush) begin
            // reset all
            if_id <= '0;
        end else if (!stall) begin
            if_id.pcValue <= pcReg;
            if_id.inst    <= inst;
        end else if (stall) begin
            if_id <= if_id; // hold IF/ID reg
        end
    end

    // Decode
    word_t inst_bits;
    logic [5:0] opcode, funct;
    logic [15:0] imm16;
    logic imm_sign;
    logic [25:0] jumpAddr;

    assign inst_bits = if_id.inst;
    assign opcode    = inst_bits[31:26];
    assign funct     = inst_bits[5:0];
    assign imm16     = inst_bits[15:0];
    assign imm_sign  = imm16[15];
    assign jumpAddr  = inst_bits[25:0];

    logic [31:0] if_id_pc;
    assign if_id_pc = if_id.pcValue;

    // combinational logic for control signals
    always @(*) begin
        // default values
        aluOp       = ALU_ADD;
        useImm      = 1'b0;
        useShamt    = 1'b0;
        regWrite    = 1'b0;
        memRead     = 1'b0;
        memWrite    = 1'b0;
        memToReg    = 1'b0;
        memReadType = MEM_READ_NONE;
        memWriteType = MEM_WRITE_NONE;
        useMdu      = 1'b0;
        mduStart    = 1'b0;
        mduOp       = MDU_READ_HI;
        branch      = BR_NONE;
        dest        = 5'd0; // default write $0
        immExt      = {{16{imm_sign}}, imm16}; // sign-extend
        linkValue   = if_id_pc + 32'd8; // for jal/jalr
        jumpIndex   = jumpAddr;
        isSyscall   = 1'b0;
        overflowCheck = 1'b0;
        useRs       = 1'b0;
        useRt       = 1'b0;

        // Address opcode
        if (!(inst_bits == 32'b0 && if_id.pcValue == 32'd0)) begin
        case(opcode)
            6'b000000: begin // R-type
                case(funct)
                    6'b100000: begin // add
                        aluOp    = ALU_ADD;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                        overflowCheck = 1'b1;
                    end
                    6'b100001: begin // addu
                        aluOp    = ALU_ADDU;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100010: begin // sub
                        aluOp    = ALU_SUB;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                        overflowCheck = 1'b1;
                    end
                    6'b100011: begin // subu
                        aluOp    = ALU_SUBU;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b000000: begin // sll
                        aluOp    = ALU_SLL;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRt    = 1'b1;
                        useShamt = 1'b1;
                    end
                    6'b000010: begin // srl
                        aluOp    = ALU_SRL;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRt    = 1'b1;
                        useShamt = 1'b1;
                    end
                    6'b000011: begin // sra
                        aluOp    = ALU_SRA;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRt    = 1'b1;
                        useShamt = 1'b1;
                    end
                    6'b000100: begin // sllv
                        aluOp    = ALU_SLL;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b000110: begin // srlv
                        aluOp    = ALU_SRL;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b000111: begin // srav
                        aluOp    = ALU_SRA;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100100: begin // and
                        aluOp    = ALU_AND;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100101: begin // or
                        aluOp    = ALU_OR;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100110: begin // xor
                        aluOp    = ALU_XOR;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b100111: begin // nor
                        aluOp    = ALU_NOR;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b101010: begin // slt
                        aluOp    = ALU_SLT;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b101011: begin // sltu
                        aluOp    = ALU_SLTU;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b001000: begin // jr
                        branch   = BR_JR;
                        useRs    = 1'b1;
                    end
                    6'b001001: begin // jalr
                        branch   = BR_JALR;
                        regWrite = 1'b1;
                        dest     = if_rd;
                        useRs    = 1'b1;
                    end
                    6'b011000: begin // mult
                        useMdu   = 1'b1;
                        mduStart = 1'b1;
                        mduOp    = MDU_START_SIGNED_MUL;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b011001: begin // multu
                        useMdu   = 1'b1;
                        mduStart = 1'b1;
                        mduOp    = MDU_START_UNSIGNED_MUL;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b011010: begin // div
                        useMdu   = 1'b1;
                        mduStart = 1'b1;
                        mduOp    = MDU_START_SIGNED_DIV;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b011011: begin // divu
                        useMdu   = 1'b1;
                        mduStart = 1'b1;
                        mduOp    = MDU_START_UNSIGNED_DIV;
                        useRs    = 1'b1;
                        useRt    = 1'b1;
                    end
                    6'b010000: begin // mfhi
                        useMdu   = 1'b1;
                        mduOp    = MDU_READ_HI;
                        regWrite = 1'b1;
                        dest     = if_rd;
                    end
                    6'b010001: begin // mthi
                        useMdu   = 1'b1;
                        mduOp    = MDU_WRITE_HI;
                        useRs    = 1'b1;
                    end
                    6'b010010: begin // mflo
                        useMdu   = 1'b1;
                        mduOp    = MDU_READ_LO;
                        regWrite = 1'b1;
                        dest     = if_rd;
                    end
                    6'b010011: begin // mtlo
                        useMdu   = 1'b1;
                        mduOp    = MDU_WRITE_LO;
                        useRs    = 1'b1;
                    end
                    6'b001100: begin // syscall
                        isSyscall = 1'b1;
                        useRs     = 1'b1;
                        useRt     = 1'b1;
                    end
                    default: begin
                        // NOP / unimplemented
                    end 
                endcase
            end
            6'b001000: begin // addi
                aluOp    = ALU_ADD;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
                overflowCheck = 1'b1;
            end
            6'b001001: begin // addiu
                aluOp    = ALU_ADDU;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
            end
            6'b001100: begin // andi
                aluOp    = ALU_AND;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
                immExt   = {{16{1'b0}}, imm16};
            end
            6'b001101: begin // ori
                aluOp    = ALU_OR;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
                immExt   = {{16{1'b0}}, imm16};
            end
            6'b001110: begin // xori
                aluOp    = ALU_XOR;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
                immExt   = {{16{1'b0}}, imm16};
            end
            6'b001010: begin // slti
                aluOp    = ALU_SLT;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
            end
            6'b001011: begin // sltiu
                aluOp    = ALU_SLTU;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
                useRs    = 1'b1;
            end
            6'b001111: begin // lui
                aluOp    = ALU_LUI;
                useImm   = 1'b1;
                regWrite = 1'b1;
                dest     = if_rt;
            end
            6'b000100: begin // beq
                branch   = BR_BEQ;
                useRs    = 1'b1;
                useRt    = 1'b1;
            end
            6'b000101: begin // bne
                branch   = BR_BNE;
                useRs    = 1'b1;
                useRt    = 1'b1;
            end
            6'b000110: begin // blez
                branch   = BR_BLEZ;
                useRs    = 1'b1;
            end
            6'b000111: begin // bgtz
                branch   = BR_BGTZ;
                useRs    = 1'b1;
            end
            6'b000001: begin // bgez / bltz
                useRs    = 1'b1;
                if (if_rt == 5'b00001) begin
                    branch = BR_BGEZ;
                end else if (if_rt == 5'b00000) begin
                    branch = BR_BLTZ;
                end
            end
            6'b000011: begin // jal
                branch   = BR_JAL;
                aluOp    = ALU_PASS;
                regWrite = 1'b1;
                dest     = 5'd31; // $ra
            end
            6'b000010: begin // j
                branch   = BR_J;
            end
            6'b100000: begin // lb
                aluOp       = ALU_ADD;
                regWrite    = 1'b1;
                memToReg    = 1'b1;
                memRead     = 1'b1;
                memReadType = MEM_READ_BYTE_SIGNED;
                useImm      = 1'b1;
                dest        = if_rt;
                useRs       = 1'b1;
            end
            6'b100100: begin // lbu
                aluOp       = ALU_ADD;
                regWrite    = 1'b1;
                memToReg    = 1'b1;
                memRead     = 1'b1;
                memReadType = MEM_READ_BYTE_UNSIGNED;
                useImm      = 1'b1;
                dest        = if_rt;
                useRs       = 1'b1;
            end
            6'b100001: begin // lh
                aluOp       = ALU_ADD;
                regWrite    = 1'b1;
                memToReg    = 1'b1;
                memRead     = 1'b1;
                memReadType = MEM_READ_HALF_SIGNED;
                useImm      = 1'b1;
                dest        = if_rt;
                useRs       = 1'b1;
            end
            6'b100101: begin // lhu
                aluOp       = ALU_ADD;
                regWrite    = 1'b1;
                memToReg    = 1'b1;
                memRead     = 1'b1;
                memReadType = MEM_READ_HALF_UNSIGNED;
                useImm      = 1'b1;
                dest        = if_rt;
                useRs       = 1'b1;
            end
            6'b100011: begin // lw
                aluOp       = ALU_ADD;
                regWrite    = 1'b1;
                memToReg    = 1'b1;
                memRead     = 1'b1;
                memReadType = MEM_READ_WORD;
                useImm      = 1'b1;
                dest        = if_rt;
                useRs       = 1'b1;
            end
            6'b101000: begin // sb
                aluOp        = ALU_ADD;
                memWrite     = 1'b1;
                memWriteType = MEM_WRITE_BYTE;
                useImm       = 1'b1;
                useRs        = 1'b1;
                useRt        = 1'b1;
            end
            6'b101001: begin // sh
                aluOp        = ALU_ADD;
                memWrite     = 1'b1;
                memWriteType = MEM_WRITE_HALF;
                useImm       = 1'b1;
                useRs        = 1'b1;
                useRt        = 1'b1;
            end
            6'b101011: begin // sw
                aluOp        = ALU_ADD;
                memWrite     = 1'b1;
                memWriteType = MEM_WRITE_WORD;
                useImm       = 1'b1;
                useRs        = 1'b1;
                useRt        = 1'b1;
            end
            default: begin
                // NOP / unimplemented
            end
        endcase
        end
    end

    // Stall logic
    logic stallLoadUse;
    logic stallMdu;
    assign stallLoadUse =
        id_ex.memToReg && // load inst in EX stage
    (
        (useRs && (id_ex.dest != 5'd0) && (id_ex.dest == dec_rs)) ||
        (useRt && (id_ex.dest != 5'd0) && (id_ex.dest == dec_rt))
    );
    assign stallMdu = useMdu && (mduBusy || id_ex.mduStart);
    assign stall = stallLoadUse || stallMdu;

    // ID/EX register
    always_ff @(posedge clock) begin
        if (reset || stall) begin
            id_ex <= '0; // bubble to stall
        end else begin
            id_ex.pcValue   <= if_id.pcValue;
            id_ex.inst      <= if_id.inst;
            id_ex.rsVal     <= rf_rs_val;
            id_ex.rtVal     <= rf_rt_val;
            id_ex.immExt    <= immExt;
            id_ex.linkValue <= linkValue;
            id_ex.rs        <= dec_rs;
            id_ex.rt        <= dec_rt;
            id_ex.rd        <= dec_rd;
            id_ex.dest      <= dest;
            // control signals
            id_ex.regWrite  <= regWrite;
            id_ex.memToReg  <= memToReg;
            id_ex.memRead   <= memRead;
            id_ex.memWrite  <= memWrite;
            id_ex.useImm    <= useImm;
            id_ex.useShamt  <= useShamt;
            id_ex.aluOp     <= aluOp;
            id_ex.branch    <= branch;
            id_ex.jumpIndex <= jumpIndex;
            id_ex.memReadType  <= memReadType;
            id_ex.memWriteType <= memWriteType;
            id_ex.mduUse    <= useMdu;
            id_ex.mduStart  <= mduStart;
            id_ex.mduOp     <= mduOp;
            id_ex.isSyscall <= isSyscall;
            id_ex.overflowCheck <= overflowCheck;
        end
    end

    // Forward helper
    word_t memStageData, wbStageData;
    word_t aluInput1, aluInput2, aluCalcResult, aluRealResult;
    logic aluOverflow;
    ALU alu (
        .op(id_ex.aluOp),
        .input1(aluInput1),
        .input2(aluInput2),
        .result(aluCalcResult),
        .overflow(aluOverflow)
    );
    logic exception;
    assign exception = aluOverflow && id_ex.overflowCheck;

    // r-type or load inst
    assign wbStageData = mem_wb.memToReg ? mem_wb.memOut : mem_wb.aluExResult;

    // address forwarding logics and choose correct rs&rt vals
    logic forward_rs_ex_mem, forward_rs_mem_wb, forward_rt_ex_mem, forward_rt_mem_wb;

    assign forward_rs_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 && // not write into $0
     ex_mem.dest == id_ex.rs); // rs not written yet

    assign forward_rs_mem_wb = 
    (mem_wb.regWrite &&
     mem_wb.dest != 5'd0 &&
     mem_wb.dest == id_ex.rs);

    assign forward_rt_ex_mem =
    (ex_mem.regWrite &&
     ex_mem.dest != 5'd0 &&
     ex_mem.dest == id_ex.rt);

    assign forward_rt_mem_wb = 
    (mem_wb.regWrite &&
     mem_wb.dest != 5'd0 &&
     mem_wb.dest == id_ex.rt);

    word_t forwardRsVal, forwardRtVal;

    assign forwardRsVal =
    forward_rs_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rs_mem_wb ? wbStageData : id_ex.rsVal);

    assign forwardRtVal =
    forward_rt_ex_mem ? (ex_mem.memToReg ? memStageData : ex_mem.aluExResult) :
    (forward_rt_mem_wb ? wbStageData : id_ex.rtVal);

    word_t mduOp1, mduOp2, mduDataRead;
    logic mduStartExec;
    assign mduOp1 = forwardRsVal;
    assign mduOp2 = forwardRtVal;
    assign mduStartExec = id_ex.mduStart && !mduBusy;
    MultiplicationDivisionUnit mdu (
        .reset(reset),
        .clock(clock),
        .operand1(mduOp1),
        .operand2(mduOp2),
        .operation(id_ex.mduOp),
        .start(mduStartExec),
        .busy(mduBusy),
        .dataRead(mduDataRead)
    );

    // branch logics
    logic [31:0] pcBase;
    logic [25:0] branchIndex;
    assign pcBase = id_ex.pcValue;
    assign branchIndex = id_ex.jumpIndex;

    logic [3:0] pcUpper;
    assign pcUpper = pcBase[31:28];

    // j & jal
    logic [31:0] jTarget;
    assign jTarget = {pcUpper, branchIndex, 2'b00};

    // beq
    logic [31:0] shiftOffset;
    assign shiftOffset = id_ex.immExt << 2;
    logic [31:0] beqTarget;
    assign beqTarget = pcBase + 32'd4 + shiftOffset;

    // Extract id_ex res
    branch_t id_ex_branch;
    reg_id_t id_ex_rs, id_ex_rt;
    word_t   id_ex_rs_val, id_ex_rt_val;
    logic    id_ex_use_imm;
    word_t   id_ex_imm_ext;
    word_t   id_ex_link_value;

    assign id_ex_branch     = id_ex.branch;
    assign id_ex_rs         = id_ex.rs;
    assign id_ex_rt         = id_ex.rt;
    assign id_ex_rs_val     = id_ex.rsVal;
    assign id_ex_rt_val     = id_ex.rtVal;
    assign id_ex_use_imm    = id_ex.useImm;
    assign id_ex_imm_ext    = id_ex.immExt;
    assign id_ex_link_value = id_ex.linkValue;

    logic branchTaken;
    word_t branchTarget;

    always @(*) begin

       // correct vals
       aluInput1 = id_ex.useShamt ? {27'b0, id_ex.inst[10:6]} : forwardRsVal;
       aluInput2 = id_ex_use_imm ? id_ex_imm_ext : forwardRtVal;

       if (id_ex.isSyscall) begin
            aluRealResult = forwardRsVal;
       end else if (id_ex.mduUse && (id_ex.mduOp == MDU_READ_HI || id_ex.mduOp == MDU_READ_LO)) begin
            aluRealResult = mduDataRead;
       end else if (id_ex_branch == BR_JAL || id_ex_branch == BR_JALR) begin
            aluRealResult = id_ex_link_value;
       end else begin
            aluRealResult = aluCalcResult;
       end

       branchTaken = 1'b0;
       branchTarget = 32'd0;

       case(id_ex_branch)
            BR_BEQ: begin
                branchTaken = (forwardRsVal == forwardRtVal);
                branchTarget = beqTarget;
            end
            BR_BNE: begin
                branchTaken = (forwardRsVal != forwardRtVal);
                branchTarget = beqTarget;
            end
            BR_BLEZ: begin
                branchTaken = ($signed(forwardRsVal) <= $signed(32'd0));
                branchTarget = beqTarget;
            end
            BR_BGTZ: begin
                branchTaken = ($signed(forwardRsVal) > $signed(32'd0));
                branchTarget = beqTarget;
            end
            BR_BGEZ: begin
                branchTaken = ($signed(forwardRsVal) >= $signed(32'd0));
                branchTarget = beqTarget;
            end
            BR_BLTZ: begin
                branchTaken = ($signed(forwardRsVal) < $signed(32'd0));
                branchTarget = beqTarget;
            end
            BR_J: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JAL: begin
                branchTaken = 1'b1;
                branchTarget = jTarget;
            end
            BR_JR: begin
                branchTaken = 1'b1;
                branchTarget = forwardRsVal;
            end
            BR_JALR: begin
                branchTaken = 1'b1;
                branchTarget = forwardRsVal;
            end
            default: begin
                // already initialized, do nothing
            end
         endcase
    end

    assign jumpEnabled = branchTaken;
    assign jumpPC = branchTarget;

    // EX/MEM register
    always_ff @(posedge clock) begin
        if (reset) begin
            ex_mem <= '0;
        end else begin
            ex_mem.pcValue      <= id_ex.pcValue;
            ex_mem.inst         <= id_ex.inst;
            ex_mem.aluExResult  <= aluRealResult;
            ex_mem.swVal        <= forwardRtVal;
            ex_mem.dest         <= id_ex.dest;
            ex_mem.exception    <= exception;
            // control signals
            if (exception) begin
                ex_mem.regWrite     <= 1'b0;
                ex_mem.memToReg     <= 1'b0;
                ex_mem.memRead      <= 1'b0;
                ex_mem.memWrite     <= 1'b0;
                ex_mem.isSyscall    <= 1'b0;
                ex_mem.memReadType  <= MEM_READ_NONE;
                ex_mem.memWriteType <= MEM_WRITE_NONE;
            end else begin
                ex_mem.regWrite     <= id_ex.regWrite;
                ex_mem.memToReg     <= id_ex.memToReg;
                ex_mem.memRead      <= id_ex.memRead;
                ex_mem.memWrite     <= id_ex.memWrite;
                ex_mem.isSyscall    <= id_ex.isSyscall;
                ex_mem.memReadType  <= id_ex.memReadType;
                ex_mem.memWriteType <= id_ex.memWriteType;
            end
        end
    end

    // MEM stage
    word_t memRawData;
    word_t memReadData;
    word_t memWriteData;
    word_t memWriteAddr;
    logic memWriteEnabled;

    assign memWriteAddr = {ex_mem.aluExResult[31:2], 2'b00};
    assign memWriteEnabled = (ex_mem.memWriteType != MEM_WRITE_NONE);

    always @(*) begin
        memWriteData = ex_mem.swVal;
        case (ex_mem.memWriteType)
            MEM_WRITE_BYTE: begin
                case (ex_mem.aluExResult[1:0])
                    2'b00: memWriteData = {memRawData[31:8], ex_mem.swVal[7:0]};
                    2'b01: memWriteData = {memRawData[31:16], ex_mem.swVal[7:0], memRawData[7:0]};
                    2'b10: memWriteData = {memRawData[31:24], ex_mem.swVal[7:0], memRawData[15:0]};
                    2'b11: memWriteData = {ex_mem.swVal[7:0], memRawData[23:0]};
                endcase
            end
            MEM_WRITE_HALF: begin
                case (ex_mem.aluExResult[1])
                    1'b0: memWriteData = {memRawData[31:16], ex_mem.swVal[15:0]};
                    1'b1: memWriteData = {ex_mem.swVal[15:0], memRawData[15:0]};
                endcase
            end
            MEM_WRITE_WORD: begin
                memWriteData = ex_mem.swVal;
            end
            default: begin
                memWriteData = ex_mem.swVal;
            end
        endcase
    end

    DataMemory dataMemory (
        .clock(clock),
        .reset(reset),
        .address(ex_mem.aluExResult),
        .writeEnabled(memWriteEnabled),
        .writeInput(memWriteData),
        .readResult(memRawData)
    );

    always @(*) begin
        memReadData = memRawData;
        case (ex_mem.memReadType)
            MEM_READ_BYTE_SIGNED: begin
                case (ex_mem.aluExResult[1:0])
                    2'b00: memReadData = {{24{memRawData[7]}}, memRawData[7:0]};
                    2'b01: memReadData = {{24{memRawData[15]}}, memRawData[15:8]};
                    2'b10: memReadData = {{24{memRawData[23]}}, memRawData[23:16]};
                    2'b11: memReadData = {{24{memRawData[31]}}, memRawData[31:24]};
                endcase
            end
            MEM_READ_BYTE_UNSIGNED: begin
                case (ex_mem.aluExResult[1:0])
                    2'b00: memReadData = {24'h000000, memRawData[7:0]};
                    2'b01: memReadData = {24'h000000, memRawData[15:8]};
                    2'b10: memReadData = {24'h000000, memRawData[23:16]};
                    2'b11: memReadData = {24'h000000, memRawData[31:24]};
                endcase
            end
            MEM_READ_HALF_SIGNED: begin
                case (ex_mem.aluExResult[1])
                    1'b0: memReadData = {{16{memRawData[15]}}, memRawData[15:0]};
                    1'b1: memReadData = {{16{memRawData[31]}}, memRawData[31:16]};
                endcase
            end
            MEM_READ_HALF_UNSIGNED: begin
                case (ex_mem.aluExResult[1])
                    1'b0: memReadData = {16'h0000, memRawData[15:0]};
                    1'b1: memReadData = {16'h0000, memRawData[31:16]};
                endcase
            end
            MEM_READ_WORD: begin
                memReadData = memRawData;
            end
            default: begin
                memReadData = memRawData;
            end
        endcase
    end

    // choose through r-type or load inst
    assign memStageData = ex_mem.memToReg ? memReadData : ex_mem.aluExResult;
        
    // MEM/WB register
    always_ff @(posedge clock) begin
        if (reset) begin
            mem_wb <= '0;
        end else begin
            mem_wb.pcValue      <= ex_mem.pcValue;
            mem_wb.inst         <= ex_mem.inst;
            mem_wb.aluExResult <= ex_mem.aluExResult;
            mem_wb.memOut      <= ex_mem.isSyscall ? ex_mem.swVal : memReadData;
            mem_wb.dest         <= ex_mem.dest;
            // control signals
            mem_wb.regWrite     <= ex_mem.regWrite;
            mem_wb.memToReg     <= ex_mem.memToReg;
            mem_wb.isSyscall    <= ex_mem.isSyscall;
            mem_wb.exception    <= ex_mem.exception;
        end
    end

    // write back
    assign wbWriteEnabled  = mem_wb.regWrite && !reset;
    assign wbWriteReg = mem_wb.dest;
    assign wbData = wbStageData;

    // print output
        always @(posedge clock) begin
        if (!reset && wbWriteEnabled) begin
            $display("@%h: $%2d <= %h", mem_wb.pcValue, mem_wb.dest, wbData);
        end
        if (memWriteEnabled && !reset) begin
            $display("@%h: *%h <= %h", ex_mem.pcValue, memWriteAddr, memWriteData);
        end
        if (!reset && mem_wb.isSyscall && !mem_wb.exception) begin
            case (mem_wb.aluExResult)
                32'd1: $display("%d", $signed(mem_wb.memOut));
                32'd10: $finish;
                default: $finish;
            endcase
        end
        if (!reset && mem_wb.exception) begin
            $display("Runtime exception at 0x%h: arithmetic overflow", mem_wb.pcValue);
            $finish;
        end
    end
endmodule

`endif
