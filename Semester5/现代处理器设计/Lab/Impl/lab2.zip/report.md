### 实验二：32 位 ALU 设计实验报告

23级图灵实验班 2023202300 张昕跃 

-----

借助实验一中实现了的32位两级超前进位加法器Adder，调用该接口来实现我ALU中的加减法逻辑。

而对于其他的逻辑和移位运算，直接调用对应运算符就可以。~~（不过AI的建议是连加减法都应该直接用内置的运算符）~~

不过这里核心是想让我们体验体验多文件项目就是了。

---

### 具体实现

- **算术运算**：实例化实现的 32 位超前进位加法器 `adder`，完成加法，稍微改造复用其输出完成减法（`A + (~B) + 1`），也就是先计算`A + (~B)`，再通过`wire与assign +1`就行了。
- **逻辑运算**：直接使用布尔运算符实现 `AND/OR/XOR/NOR`。
- **移位运算**：支持逻辑左移、逻辑右移与算术右移，注意每次移位位数对应 `A[4:0]` 。

```verilog
case (Op)
    // 有符号与无符号就是多了溢出监测而已
    6'b100000: C = add_result;                 // ADD
    6'b100001: C = add_result;                 // ADDU
    6'b100010: C = sub_result;                 // SUB
    6'b100011: C = sub_result;                 // SUBU
    6'b000000: C = B <<  A[4:0];               // SLL
    6'b000010: C = B >>  A[4:0];               // SRL
    6'b000011: C = $signed(B) >>> A[4:0];      // SRA
    6'b100100: C = A & B;                      // AND
    6'b100101: C = A | B;                      // OR
    6'b100110: C = A ^ B;                      // XOR
    6'b100111: C = ~(A | B);                   // NOR
    default:   C = 32'hxxxxxxxx;
endcase
```

### 溢出检测
- **有符号加法**：当输入最高位同号且结果与输入符号位不同，则 `Over = 1`；
- **有符号减法**：当被减数与减数最高位不同，且结果符号与被减数不同，则判断溢出；
- **无符号运算** 与移位、逻辑操作不关心溢出，`Over` 置 0。

> 其实这个在文档的cov计算已经给出了 `cov = (in1[31] == in2[31] && in1[31] != ans[31])`，对应换成ABC就可以

``` verilog
    if (A[31] == B[31] && A[31] != C[31]) begin
        Over = 1'b1;
    end else begin
        Over = 1'b0;
    end
```

```verilog
case (Op)
    6'b100000: C = add_result;                 // ADD
    6'b100001: C = add_result;                 // ADDU
    6'b100010: C = sub_result;                 // SUB
    6'b100011: C = sub_result;                 // SUBU
    6'b000000: C = B <<  A[4:0];               // SLL
    6'b000010: C = B >>  A[4:0];               // SRL
    6'b000011: C = $signed(B) >>> A[4:0];      // SRA
    6'b100100: C = A & B;                      // AND
    6'b100101: C = A | B;                      // OR
    6'b100110: C = A ^ B;                      // XOR
    6'b100111: C = ~(A | B);                   // NOR
    default:   C = 32'hxxxxxxxx;
endcase
```

### 答案验证

correct变量已经在.tb的激励文件中写好了，只要恒为1就是对的。

### 实验结果
- `image.png` 是最开始的变量值。
![算术运算波形](image.png)
- `image2.png` 是correct变量下一次变化的蒂法，在最后，说明它的值始终没有改变过，恒为1，实验结果正确。
![逻辑与移位运算波形](image2.png)

