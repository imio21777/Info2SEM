from sympy import symbols, And, Or, Xor, logic, sympify

def to_verilog(expr, name):
    """Converts a SymPy boolean expression to a Verilog assign statement."""
    s = str(expr).replace('(', '( ').replace(')', ' )')
    # SymPy uses | for Or, & for And, ~ for Not, ^ for Xor. Verilog is the same.
    return f"assign {name} = {s};"

# --- Part 1: Generate 4-bit CLA Block Logic ---
print("//" + "="*50)
print("// Verilog code for 4-bit CLA block (adder_4bit_unit)")
print("//" + "="*50)

# Define symbols for a 4-bit block using a list for correct ordering
p = [symbols(f'p[{i}]') for i in range(4)]
g = [symbols(f'g[{i}]') for i in range(4)]
c_in = symbols('c_in')

# Generate internal carry expressions
c = [c_in]
for i in range(4):
    c_next = Or(g[i], And(p[i], c[i]))
    c.append(c_next)

print("\n// Internal carry logic")
# c[0] is c_in, c[1] is carry out of bit 0, etc.
print(to_verilog(logic.simplify_logic(c[1]), "c1"))
print(to_verilog(logic.simplify_logic(c[2]), "c2"))
print(to_verilog(logic.simplify_logic(c[3]), "c3"))
# c[4] is the final carry out of the 4-bit block
# print(to_verilog(logic.simplify_logic(c[4]), "c_out_wire")) # This is not needed for the final module interface

# Generate Group Propagate (PG) and Group Generate (GG)
# PG is true if all p[i] are true
pg_expr = And(*p)
# GG is true if the block generates a carry internally, regardless of c_in
gg_expr = c[4].subs(c_in, 0)

print("\n// Group Propagate (PG) and Group Generate (GG) logic")
print(to_verilog(logic.simplify_logic(pg_expr), "PG"))
print(to_verilog(logic.simplify_logic(gg_expr), "GG"))
print("\n")


# --- Part 2: Generate Lookahead Carry Unit Logic for 8 groups (32-bit) ---
print("//" + "="*50)
print("// Verilog code for Lookahead Carry Unit (lookahead_carry_unit)")
print("//" + "="*50)

# Define symbols for 8 groups using a list for correct ordering
PG = [symbols(f'PG[{i}]') for i in range(8)]
GG = [symbols(f'GG[{i}]') for i in range(8)]
C_in = symbols('C_in') # Overall carry-in for the 32-bit adder

# Generate group carry expressions
C = [C_in]
for i in range(8):
    c_next = Or(GG[i], And(PG[i], C[i]))
    C.append(c_next)

print("\n// Group carry logic (carries into each 4-bit block)")
# C[0] is the input C_in. We need to output C[1] through C[7].
for i in range(1, 8):
    # Output name needs to match the Verilog wire name, e.g., C[1], C[2]...
    print(to_verilog(logic.simplify_logic(C[i]), f"C[{i}]"))

print("\n")