//==================================================
// Verilog code for 4-bit CLA block (adder_4bit_unit)
//==================================================

// Internal carry logic
assign c1 = g[0] | ( c_in & p[0] );
assign c2 = g[1] | ( g[0] & p[1] ) | ( c_in & p[0] & p[1] );
assign c3 = g[2] | ( g[1] & p[2] ) | ( g[0] & p[1] & p[2] ) | ( c_in & p[0] & p[1] & p[2] );

// Group Propagate (PG) and Group Generate (GG) logic
assign PG = p[0] & p[1] & p[2] & p[3];
assign GG = g[3] | ( g[2] & p[3] ) | ( g[1] & p[2] & p[3] ) | ( g[0] & p[1] & p[2] & p[3] );


//==================================================
// Verilog code for Lookahead Carry Unit (lookahead_carry_unit)
//==================================================

// Group carry logic (carries into each 4-bit block)
assign C[1] = GG[0] | ( C_in & PG[0] );
assign C[2] = GG[1] | ( GG[0] & PG[1] ) | ( C_in & PG[0] & PG[1] );
assign C[3] = GG[2] | ( GG[1] & PG[2] ) | ( GG[0] & PG[1] & PG[2] ) | ( C_in & PG[0] & PG[1] & PG[2] );
assign C[4] = GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) );
assign C[5] = GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) );
assign C[6] = GG[5] | ( PG[5] & ( GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) ) ) );
assign C[7] = GG[6] | ( PG[6] & ( GG[5] | ( PG[5] & ( GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) ) ) ) ) );