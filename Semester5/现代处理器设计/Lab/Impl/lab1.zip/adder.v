// adder.v

// ============================================================================
// Module 1: 4-bit Carry-Lookahead Adder Block (adder_4bit_unit)
// ============================================================================
module adder_4bit_unit (
    input  [3:0] a,
    input  [3:0] b,
    input        c_in,
    output [3:0] sum,
    output       PG,  // Group Propagate
    output       GG   // Group Generate
);

    // Wires for bit-wise propagate and generate
    wire [3:0] p;
    wire [3:0] g;

    // Wires for internal carries
    wire c1, c2, c3, c_out_wire;

    // Bit-wise p and g logic
    assign p = a ^ b;
    assign g = a & b;

    // Sum logic
    assign sum[0] = p[0] ^ c_in;
    assign sum[1] = p[1] ^ c1;
    assign sum[2] = p[2] ^ c2;
    assign sum[3] = p[3] ^ c3;

    // --- PASTE PYTHON GENERATED CODE FOR 4-BIT CLA HERE ---
    // Internal carry logic
    assign c1 = g[0] | ( c_in & p[0] );
    assign c2 = g[1] | ( g[0] & p[1] ) | ( c_in & p[0] & p[1] );
    assign c3 = g[2] | ( g[1] & p[2] ) | ( g[0] & p[1] & p[2] ) | ( c_in & p[0] & p[1] & p[2] );

    // Group Propagate (PG) and Group Generate (GG) logic
    assign PG = p[0] & p[1] & p[2] & p[3];
    assign GG = g[3] | ( g[2] & p[3] ) | ( g[1] & p[2] & p[3] ) | ( g[0] & p[1] & p[2] & p[3] );

endmodule


// ============================================================================
// Module 2: Lookahead Carry Unit for 8 Groups (lookahead_carry_unit)
// ============================================================================
module lookahead_carry_unit (
    input  [7:0] PG,
    input  [7:0] GG,
    input        C_in,
    output [7:1] C     // Carries for blocks 1 through 7
);

    // --- PASTE PYTHON GENERATED CODE FOR LOOKAHEAD UNIT HERE ---
    // Group carry logic (carries into each 4-bit block)

    assign C[1] = GG[0] | ( C_in & PG[0] );
    assign C[2] = GG[1] | ( GG[0] & PG[1] ) | ( C_in & PG[0] & PG[1] );
    assign C[3] = GG[2] | ( GG[1] & PG[2] ) | ( GG[0] & PG[1] & PG[2] ) | ( C_in & PG[0] & PG[1] & PG[2] );
    assign C[4] = GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) );
    assign C[5] = GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) );
    assign C[6] = GG[5] | ( PG[5] & ( GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) ) ) );
    assign C[7] = GG[6] | ( PG[6] & ( GG[5] | ( PG[5] & ( GG[4] | ( PG[4] & ( GG[3] | ( PG[3] & ( GG[2] | ( PG[2] & ( GG[1] | ( PG[1] & ( GG[0] | ( C_in & PG[0] ) ) ) ) ) ) ) ) ) ) ) ) );


endmodule


// ============================================================================
// Module 3: Top-level 32-bit Adder (This is the module you will test)
// ============================================================================
`default_nettype none
module adder(
    input  wire [31:0] a,
    input  wire [31:0] b,
    output wire [31:0] sum
);

    // Wires for Group Propagate and Group Generate from each 4-bit block
    wire [7:0] group_PG;
    wire [7:0] group_GG;

    // Wires for carries between the blocks. C[0] is the global carry-in.
    // C[1] is carry into block 1, C[2] is carry into block 2, etc.
    wire [7:0] group_C;

    // The overall carry-in is 0 for an adder.
    assign group_C[0] = 1'b0;

    // Instantiate the top-level Lookahead Carry Unit
    lookahead_carry_unit lcu_inst (
        .PG   (group_PG),
        .GG   (group_GG),
        .C_in (group_C[0]),
        .C    (group_C[7:1])
    );

    // Instantiate 8 of the 4-bit CLA blocks using a generate loop
    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : cla_blocks
            adder_4bit_unit cla_inst (
                .a     (a[4*i + 3 : 4*i]),
                .b     (b[4*i + 3 : 4*i]),
                .c_in  (group_C[i]),
                .sum   (sum[4*i + 3 : 4*i]),
                .PG    (group_PG[i]),
                .GG    (group_GG[i])
            );
        end
    endgenerate

endmodule
`default_nettype wire